/*
    Лабораторная работа №2
    По дисциплине ЛОИС
	Белоус Павел 921704
	Исходный код программы взял у:
    Касперович Александр, Минеев Владислав, группа 921701
    Вариант А: Подсчитать количество подформул в формуле логических высказываний
    Вариант 4: Проверить формулу на нейтральность
    Цель: Реализовать процедурную программу, решающую задачу обработки формул языка логики высказываний.
*/

package sample;

import java.util.ArrayList;
import java.util.List;

public class NeutralFormula {

    private final char[] ALPHABET = {'A', 'B', 'C','D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
                                     'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

    private final String[] OPERATIONS = {"!", "&", "|", "~", ">"};

    private String formula;

    public List<List<String>> matrix = new ArrayList<>();

    NeutralFormula(String formula) {
        this.formula = formula;
    }

    private void makeTable(int numberOfSymbols, List<String> tableLine) {
        if (numberOfSymbols == 0) {
            this.matrix.add(new ArrayList<>(tableLine));
            return;
        }

        tableLine.add("1");
        makeTable(numberOfSymbols - 1, tableLine);
        tableLine.remove(tableLine.size() - 1);

        tableLine.add("0");
        makeTable(numberOfSymbols - 1, tableLine);
        tableLine.remove(tableLine.size() -1);
    }

    private void addFunctionValueAtTable() {
        matrix.get(0).add("f");
        for (int i = 1; i < matrix.size(); i++) {
            String str = "";
            str += formula;
            int functionValue = replaceExpression(str, i, -1);
            matrix.get(i).add(String.valueOf(functionValue));
        }
    }

    private int replaceExpression(String line, int lineNumber, int functionValue) {
        if(line.length() == 1){
            int index = matrix.get(0).indexOf(line);
            if(line.equals("1") || line.equals("0"))
                return functionValue;
            return Integer.parseInt(matrix.get(lineNumber).get(index));
        }

        int balance = 0;
        int left = 0, right = 0;

        for (int i = 0; i < line.length(); i++) {

            if (line.charAt(i) == '(') {
                balance++;
                if (balance == 1) {
                    left = i;
                }
            } else if (line.charAt(i) == ')') {
                balance--;
                if (balance == 0) {
                    right = i;
                    break;
                }
            }
        }

        if (left == 0 && right == 0) {
            for (int i = 0; i < line.length(); i++) {
                if(line.charAt(i) == '!'){
                    if(line.charAt(i + 1) == '1' || line.charAt(i + 1) == '0'){
                        int value = unaryOperation(Integer.parseInt(line.substring(i + 1,i + 2)));
                        functionValue = value;
                        line = line.replace(line.substring(i, i + 2), String.valueOf(functionValue));
                    }
                    else {
                        int index = matrix.get(0).indexOf(line.substring(i + 1,i + 2));
                        int value = unaryOperation(Integer.parseInt(matrix.get(lineNumber).get(index)));
                        functionValue = value;
                        line = line.replace(line.substring(i, i + 2), String.valueOf(functionValue));
                    }
                    return functionValue;
                }
            }
            int p = 3;
            int x = -2, k = 0;

            for(String operation : OPERATIONS){
                x = line.indexOf(operation);
                if(!operation.equals("!") && x > 0) {
                    k++;
                    if(line.charAt(x) == operation.charAt(0))
                        if(p > x){
                            p = x;
                        }
                }
            }





                for (String operation : OPERATIONS) {

                    if(!operation.equals("!") && line.charAt(p) == operation.charAt(0)){
                        //System.out.println("OPERATION : " + operation);

                        if(line.charAt(p - 1) == '1'){
                            if(line.charAt(p + 1) == '1'){
                                functionValue  = binaryOperation(1,1, operation);
                            }

                            else if(line.charAt(p + 1) == '0'){
                                functionValue  = binaryOperation(1,0, operation);

                            }
                            else {
                                //int index1  = matrix.get(0).indexOf(line.substring(i - 1, i));
                                int index2 = matrix.get(0).indexOf(line.substring(p + 1, p + 2));
                                functionValue  = binaryOperation(1, Integer.parseInt(matrix.get(lineNumber).get(index2)), operation );

                            }
                        }
                        else if(line.charAt(p - 1) == '0'){
                            if(line.charAt(p + 1) == '1'){
                                functionValue  = binaryOperation(0,1, operation);
                            }

                            else if(line.charAt(p + 1) == '0'){
                                functionValue  = binaryOperation(0,0, operation);

                            }
                            else {
                                //int index1  = matrix.get(0).indexOf(line.substring(p - 1, p));
                                int index2 = matrix.get(0).indexOf(line.substring(p + 1,p + 2));
                                functionValue  = binaryOperation(0, Integer.parseInt(matrix.get(lineNumber).get(index2)), operation );
                            }

                        }
                        else if(line.charAt(p + 1) == '0'){
                            if(line.charAt(p - 1) == '1'){
                                functionValue  = binaryOperation(1,0, operation);
                            }

                            else if(line.charAt(p - 1) == '0'){
                                functionValue  = binaryOperation(0,0, operation);

                            }
                            else {
                                int index1  = matrix.get(0).indexOf(line.substring(p - 1, p));
                                //int index2 = matrix.get(0).indexOf(line.substring(i + 1,i + 2));
                                functionValue  = binaryOperation(Integer.parseInt(matrix.get(lineNumber).get(index1)), 0, operation );
                            }

                        }
                        else if(line.charAt(p + 1) == '1'){
                            if(line.charAt(p - 1) == '1'){
                                functionValue  = binaryOperation(1,1, operation);
                            }

                            else if(line.charAt(p - 1) == '0'){
                                functionValue  = binaryOperation(0,0, operation);

                            }
                            else {
                                int index1  = matrix.get(0).indexOf(line.substring(p - 1, p));
                                //int index2 = matrix.get(0).indexOf(line.substring(i + 1,i + 2));
                                functionValue  = binaryOperation(Integer.parseInt(matrix.get(lineNumber).get(index1)), 1, operation );
                            }

                        }
                        else{
                            int index1  = matrix.get(0).indexOf(line.substring(p - 1, p));
                            int index2 = matrix.get(0).indexOf(line.substring(p + 1, p + 2));

                            functionValue  = binaryOperation(Integer.parseInt(matrix.get(lineNumber).get(index1)), Integer.parseInt(matrix.get(lineNumber).get(index2)), operation );
                        }
                        line = line.replace(line.substring(p - 1, p + 2), String.valueOf(functionValue));

                        //System.out.println("LINE : " + line);
                        break;
                    }

            }


            //System.out.println(line);

        } else {
            String expression = line.substring(left + 1, right);
            //System.out.println(expression);

            functionValue = replaceExpression(expression, lineNumber, functionValue);

            line = line.replace("(" + expression + ")", String.valueOf(functionValue));

            functionValue = replaceExpression(line, lineNumber, functionValue);

        }


        return functionValue;
    }

    private void makeTruthTable() {
        int symbolsNumber = 0;

        List<String> expressionAlphabet = new ArrayList<>();
        for (char symbol : ALPHABET) {
            if (formula.indexOf(symbol) != -1) {
                symbolsNumber++;
                expressionAlphabet.add(formula.substring(formula.indexOf(symbol), formula.indexOf(symbol) + 1));
            }
        }

        matrix.add(expressionAlphabet);

        List<String> list = new ArrayList<>();
        makeTable(symbolsNumber, list);

        addFunctionValueAtTable();

     //   System.out.println(matrix);
    }


//(((((((((((((((((((((((((A\/B)\/C)\/D)\/E)\/F)\/G)\/H)\/I)\/J)\/K)\/L)\/M)\/N)\/O)\/P)\/Q)\/R)\/S)\/T)\/U)\/V)\/W)\/X)\/Y)\/Z)
    public boolean isNeutralFormula() {

        makeTruthTable();

        boolean hasNull = false, hasOne = false;
        for (int i = 1; i < matrix.size(); i++) {
            if (matrix.get(i).get(matrix.get(i).size() - 1).equals("0")) {
                hasNull = true;
            }
            else {
                hasOne = true;
            }
        }

        return hasNull & hasOne;
    }


    private int unaryOperation(int value){
        if(value == 1){
            return 0;
        }
        return 1;
    }

    //Подсчет бинарной операции при заданном значении
    private int binaryOperation(int value1, int value2, String operation){
        if(operation.equals("&")){
            if(value1 == 0 && value2 == 0)
                return 0;
            if((value1 == 1 && value2 == 0) || (value1 == 0 && value2 == 1))
                return 0;
            if(value1 == 1 && value2 == 1)
                return 1;
        }
        if(operation.equals("|")){
            if(value1 == 0 && value2 == 0)
                return 0;
            if((value1 == 1 && value2 == 0) || (value1 == 0 && value2 == 1))
                return 1;
            if(value1 == 1 && value2 == 1)
                return 1;
        }

        if(operation.equals("|")){
            if(value1 == 0 && value2 == 0)
                return 0;
            if((value1 == 1 && value2 == 0) || (value1 == 0 && value2 == 1))
                return 1;
            if(value1 == 1 && value2 == 1)
                return 1;
        }
        if(operation.equals(">")){
            if(value1 == 0 && value2 == 0)
                return 1;
            if((value1 == 1 && value2 == 0) )
                return 0;
            if((value1 == 0 && value2 == 1))
                return 1;
            if(value1 == 1 && value2 == 1)
                return 1;
        }

        if(operation.equals("~")){
            if(value1 == 0 && value2 == 0)
                return 1;
            if((value1 == 0 && value2 == 1) )
                return 0;
            if((value1 == 1 && value2 == 0))
                return 0;
            if(value1 == 1 && value2 == 1)
                return 1;
        }
        return -1;
    }
}