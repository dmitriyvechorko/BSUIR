package sample;

public class FormulaChecker {


    private final static char[] ALPHABET = {'A', 'B', 'C','D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

    private static final String[] OPERATIONS = {"!", "&", "|", "~", ">"};

    private static final char[] TRUE_OPERATIONS = {'/', '\\', '!', '-', '>', '(', ')', '~'};

    private static final char[] CONSTANTS = {'1', '0'};

    private String formula;

    FormulaChecker(String formula) {
        this.formula = formula;

    }

    private void replaceAll(String replaceable, String replacing) {

        int position = formula.indexOf(replaceable);
        formula = formula.replace(replaceable, replacing);
    }


    public boolean isNeutralFormula() {
        NeutralFormula neutralFormula = new NeutralFormula(formula);
        return neutralFormula.isNeutralFormula();
    }

    private boolean correctBracketsSequence(String formula) {
        int balance = 0;
        for (int i = 0; i < formula.length(); i++) {
            if (formula.charAt(i) == '(') {
                balance++;

            } else if (formula.charAt(i) == ')') {
                balance--;

            }

            if (balance < 0) {
                return false;
            }
        }

        return balance == 0;
    }

    // Проверка на правильность введенной формулы
    public boolean checkFormula() {
        String GRAMMAR = "";
        for(char sign: ALPHABET)
            GRAMMAR+=sign;

        for(char sign: CONSTANTS)
            GRAMMAR+=sign;
        for(char sign: TRUE_OPERATIONS)
            GRAMMAR+=sign;

        for (int i = 0; i < formula.length(); i++) {
            if ((formula.charAt(i) == '>') && (i == 0 || formula.charAt(i-1) != '-')) return false;
            if (GRAMMAR.indexOf(formula.charAt(i)) == -1)
                return false;
        }
        replaceAll("->", ">");
        replaceAll("/\\", "&");
        replaceAll("\\/", "|");

        if (!correctBracketsSequence(formula)) {
            return false;
        }

        for (char sign : CONSTANTS) {
            if (formula.contains("( )".replace(' ', sign))) {
                return false;
            }
        }

        for (char sign : ALPHABET) {
            if (formula.contains("( )".replace(' ', sign))) {
                return false;
            }
        }

        if (formula.length() == 0) {
            return false;
        }
        else if (formula.length() == 1) {
            return singInAlphabet(formula.charAt(0)) || singInConstants(formula.charAt(0));
        }

        if (formula.charAt(0) != '(' || formula.charAt(formula.length() - 1) != ')') {
            return false;
        }

        if (!correctBracketsSequence(formula)) {
            return false;
        }

        String str = correctFormula(formula, false);

        return str.length() == 1;
    }

    private String correctFormula(String line, boolean key) {

        if (line == null) {
            return null;
        }

        if (line.length() == 1) {
            return line;
        }

        int balance = 0;
        int left = 0, right = 0;
        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == '(') {
                balance++;
                if (balance == 1) {
                    left = i;
                }
            }
            else if (line.charAt(i) == ')') {
                balance--;
                if (balance == 0) {
                    right = i;
                    break;
                }
            }
        }

        if (key) {
            if (left ==0 && right == line.length() - 1) {
                return null;
            }
        }

        if (left + 1 == right) {
            return null;
        }

        if (left == 0 && right == 0) {

            if (line.length() > 3) {
                return null;
            }

            line = replaceNegative(line);

            if (line.length() == 1) {
                return line;
            }

            int position = getBinaryOperationPosition(line);
            while (position != -1 && line.length() > 1) {

                if ((singInAlphabet(line.charAt(position - 1)) || singInConstants(line.charAt(position - 1))) &&
                        (singInAlphabet(line.charAt(position + 1)) || singInConstants(line.charAt(position + 1)))) {
                    line = line.replace(line.substring(position - 1, position + 2), "C");
                }
                else {
                    for (String operation : OPERATIONS) {
                        if (operation.indexOf(line.charAt(position + 1)) >= 0) {
                            return null;
                        }
                    }
                }

                position = getBinaryOperationPosition(line);

                if (position == line.length() - 1) {
                    return null;
                }
            }
        }
        else {
            String expression = line.substring(left + 1, right);
            if (left == 0 && right == line.length() - 1) {
                key = true;
            }

            String str = correctFormula(expression, key);
            str = correctFormula(str, key);

            if (str == null) {
                return null;
            }

            line = line.replace("(" + expression + ")", str);
            line = correctFormula(line, key);
        }

        return line;
    }

    private String replaceNegative(String line) {

        int operationPosition = line.indexOf('!');
        while (operationPosition >= 0 && operationPosition < line.length() - 1) {
            if (singInConstants(line.charAt(operationPosition + 1))) {
                line = line.replace(line.substring(operationPosition, operationPosition + 2), "A");
            }
            else if (singInAlphabet(line.charAt(operationPosition + 1))) {
                line = line.replace(line.substring(operationPosition, operationPosition + 2), "B");
            }
            else {
                return null;
            }

            operationPosition = line.indexOf('!');
        }

        return line;
    }

    private boolean singInAlphabet(char sign) {
        for (char symbol : ALPHABET) {
            if (symbol == sign) {
                return true;
            }
        }

        return false;
    }

    private boolean singInConstants(char sign) {
        for (char constant : CONSTANTS) {
            if (constant == sign) {
                return true;
            }
        }

        return false;
    }

    private int getBinaryOperationPosition(String line) {
        int position = -1;

        for (String operation : OPERATIONS) {
            if (operation.equals("!")) {
                continue;
            }

            position = line.indexOf(operation);
            if (position >= 0) {
                break;
            }
        }

        return position;
    }
}