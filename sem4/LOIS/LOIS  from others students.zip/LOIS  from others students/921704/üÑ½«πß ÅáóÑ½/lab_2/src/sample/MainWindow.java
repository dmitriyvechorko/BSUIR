/*
    Лабораторная работа №2
    По дисциплине ЛОИС
	Белоус Павел 921704
	Исходный код программы взял у:
    Касперович Александр, Минеев Владислав, группа 921701
    Вариант 4: Проверить является ли формула сокращенного языка логики высказываний нейтральной.
    Цель: приобрести навыки программирования алгоритмов интрепретаций и преобразований формул языка логики высказываний
    Использованные источники:
    1) Справочно проверяющая семантическая система по дисциплине ЛОИС
       Сслыка: http://scnedu.sourceforge.net/variety/_/index.html?variety=examinator.PSMIS.E.1.json
*/

package sample;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainWindow extends Application {


    @Override
    public void start(Stage primaryStage) throws Exception {

        Label enterFormulaLabel = new Label("Формула:");
        TextField formulaField = new TextField();

        formulaField.setMaxWidth(250);
        Button isNeutralFormulaButton = new Button("Проверка на нейтральность");

        VBox vBox = new VBox(new VBox(enterFormulaLabel, formulaField),
                isNeutralFormulaButton);

        vBox.setSpacing(20);

        // (((A|B)&(B|A))&((B|A)&(B|A)))

        isNeutralFormulaButton.setOnAction(actionEvent -> {
            try {
                FormulaChecker formula = new FormulaChecker(formulaField.getText());
                if (formula.checkFormula()) {
                    NeutralFormulaAlert(formula.isNeutralFormula());
                } else {
                    errorAlert();
                }
            } catch (Throwable ex) {
                errorAlert();
            }

        });

        primaryStage.setTitle("Нахождение количества подформул");
        primaryStage.setScene(new Scene(vBox, 250, 100));
        //primaryStage.setScene(new Scene(vBox, 250, 150));
        primaryStage.show();
    }

    private void errorAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);

        alert.setTitle("Ошибка");
        alert.setHeaderText("Неверная формула");
        alert.setContentText("Введите корректную формулу");

        alert.showAndWait();
    }

    private void subFormulaNumberAlert(int subFormulaNumber) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.setTitle("Количество подформул");
        alert.setHeaderText("Количество подформул: " + Integer.valueOf(subFormulaNumber).toString());

        alert.showAndWait();
    }

    private void NeutralFormulaAlert(boolean isNeutral) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.setTitle("Нейтральность");
        if (isNeutral) {
            alert.setHeaderText("Формула является нейтральной");
        } else {
            alert.setHeaderText("Формула не является нейтральной");
        }

        alert.showAndWait();
    }

    public static void main(String[] args) {

        launch(args);

    }
}