/*
    Лабораторная работа №1
    По дисциплине ЛОИС
	Белоус Павел 921704
	Исходный код программы взял у:
    Касперович Александр, Минеев Владислав, группа 921701
    Вариант А: Подсчитать количество подформул в формуле логических высказываний
    Цель: Приобрести навыки программирования алгоритмов синтаксического разбора формул языка логики высказываний.
    Использованные источники:
    1) Справочно проверяющая семантическая система по дисциплине ЛОИС
       Сслыка: http://scnedu.sourceforge.net/variety/_/index.html?variety=examinator.PSMIS.E.1.json
*/

package sample;

import java.util.HashSet;

public class ExpressionParser {

    private static final char[] ALPHABET = {'A', 'B', 'C','D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
                                            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

    private static final char[] CONSTANTS = {'0', '1'};

    private final String expression;

    public int subFormulasNumber;

    private final HashSet<String> subFormulaSet = new HashSet<>();

    public ExpressionParser(String expression) {
        this.expression = expression;
        this.subFormulasNumber = 0;
    }

    public void calculateSubFormulasNumber() {
        findAllSubformulas(this.expression);

        for (char sign : ALPHABET) {
            int x = expression.indexOf(sign);
            if(x != -1) {
                subFormulasNumber++;
            }
        }

        for (char sign : CONSTANTS) {
            int x = expression.indexOf(sign);
            if(x != -1) {
                subFormulasNumber++;
            }
        }

        subFormulasNumber += subFormulaSet.size() - 1;
    }

    private void findAllSubformulas(String expression) {

        int balance = 0, left = 0, right;

        for (int i = 0; i < expression.length(); i++) {
            if (expression.charAt(i) == '(') {
                balance++;
                if (balance == 1) {
                    left = i;
                }
            }
            else if (expression.charAt(i) == ')') {
                balance--;
                if (balance == 0) {
                    right = i;
                    findAllSubformulas(expression.substring(left + 1, right));
                }
            }
        }

        subFormulaSet.add(expression);
    }

    public String getExpression() {
        return expression;
    }
}