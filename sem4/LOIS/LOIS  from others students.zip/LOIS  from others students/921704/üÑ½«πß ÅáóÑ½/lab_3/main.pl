% /////////////////////////////////////////////////////////////////////////////////////
% Лабораторная работа 3 по дисциплине ЛОИС
% Выполнена студентом группы 921701
% БГУИР Белоус П.А.
% Исходный код взял у: Валюкевич В.И. 921703
% Вариант 1. Два берега реки. На одном из берегов есть три миссионера и три людоеда, 
% требуется с помощью лодки, вмещающей не более двух человек, переправить всех на другой берег. 
% Число присутствующих миссионеров на берегу и в лодке должно быть всегда не меньше числа людоедов.
% 01.05.2022
% Использованные материалы:
% https://www.swi-prolog.org - документация Пролога
% https://habr.com/ru/company/ruvds/blog/525014/ - обзор Пролога
% https://habr.com/ru/post/124636/ - примеры программ на Прологе

% M - number of missionaries
% O - number of ogres
exist(M, O) :-
    M >= O; 
    M = 0;
    O = 0.

write(N, M1, O1, M2, O2) :-
    write('Step '),
    writeln(N),
    write('Missionaries left: '),
    writeln(M1),
    write('Ogres left: '),
    writeln(O1),
    write('Missionaries right: '),
    writeln(M2),
    write('Ogres right: '),
    writeln(O2), nl.

% M1 - number of missionaries on side 1
% O1 - number of ogres on side 1
% M2 - number of missionaries on side 2
% O2 - number of ogres on side 2
% S - currect side
% N - step
move_rec(M1, O1, M2, O2, S, N) :-
    M1 > 0,
    O1 > 0,

    (
        (
            S = 0,

            exist(M1, O1),
            M is 1,
            O is 1,

            RM1 is M1 - M,
            RO1 is O1 - O,
            RM2 is M2 + M,
            RO2 is O2 + O,
            RN is N + 1,
    
            move_rec(RM1, RO1, RM2, RO2, 1, RN),
    
            write(N, M1, O1, M2, O2)
        );
        (
            S = 0,

            exist(M1 - 2, O1),
            M is 2,
            O is 0,

            RM1 is M1 - M,
            RO1 is O1 - O,
            RM2 is M2 + M,
            RO2 is O2 + O,
            RN is N + 1,
    
            move_rec(RM1, RO1, RM2, RO2, 1, RN),
        
            write(N, M1, O1, M2, O2)
        );
        (
            S = 0,

            exist(M1, O1 - 2),
            M is 0,
            O is 2,

            RM1 is M1 - M,
            RO1 is O1 - O,
            RM2 is M2 + M,
            RO2 is O2 + O,
            RN is N + 1,
    
            move_rec(RM1, RO1, RM2, RO2, 1, RN),
        
            write(N, M1, O1, M2, O2)
        );
        (
            S = 0,

            M1 = 1,
            O1 = 0,

            M is 1,
            O is 0,

            RM1 is M1 - M,
            RO1 is O1 - O,
            RM2 is M2 + M,
            RO2 is O2 + O,
            RN is N + 1,
    
            move_rec(RM1, RO1, RM2, RO2, 1, RN),
        
            write(N, M1, O1, M2, O2)
        );
        (
            S = 0,

            M1 = 0,
            O1 = 1,

            M is 0,
            O is 1,

            RM1 is M1 - M,
            RO1 is O1 - O,
            RM2 is M2 + M,
            RO2 is O2 + O,
            RN is N + 1,
    
            move_rec(RM1, RO1, RM2, RO2, 1, RN),
        
            write(N, M1, O1, M2, O2)
        )
    );
    (
        (
            S = 1,
    
            exist(M2 - 1, O2),
            M is 1,
            O is 0,
        
            RM1 is M1 + M,
            RO1 is O1 + O,
            RM2 is M2 - M,
            RO2 is O2 - O,
            RN is N + 1,
            
            move_rec(RM1, RO1, RM2, RO2, 0, RN),
        
            write(N, M1, O1, M2, O2)
        );
        (
            S = 1,
    
            exist(M2, O2 - 1),
            M is 0,
            O is 1,
        
            RM1 is M1 + M,
            RO1 is O1 + O,
            RM2 is M2 - M,
            RO2 is O2 - O,
            RN is N + 1,
            
            move_rec(RM1, RO1, RM2, RO2, 0, RN),
        
            write(N, M1, O1, M2, O2)
        )
    ).

% 0 - number of missionaries on side 1
% 0 - number of ogres on side 1
move_rec(0, 0, M, O, _, N) :-
    write('Step '),
    writeln(N),
    write('Missionaries left: '),
    writeln(0),
    write('Ogres left: '),
    writeln(0),
    write('Missionaries right: '),
    writeln(M),
    write('Ogres right: '),
    writeln(O), nl.

% M - number of missionaries on side 1
% O - number of ogres on side 1
move(M, O) :-
    move_rec(M, O, 0, 0, 0, 0).

main :- 
    read(M),
    read(O),
    (
        is_of_type(positive_integer, M),
        is_of_type(positive_integer, O),

        move(M, O);
        writeln("Cannot move")
    );
    (
        writeln("Incorrect input")
    ).

:- initialization(main).
