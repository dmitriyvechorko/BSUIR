﻿
////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №2 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студентом группы 921704 БГУИР Суринович
// Файл lab2.cpp содержит методы для взаимодействия с пользователем


#include <iostream>
#include <string>
#include <vector>
#include "FormulaRecognizer.h"
#include "TautologyRecognizer.h"


using namespace std;

void startPreloadedTests();
void startTautologyTester();


// test: ((!(E/\T))\/(R/\Q))
// test: (A/\(B/\(C/\(D/\(E/\(F/\(G/\(H/\(I/\(J/\(K/\(L/\(M/\(N/\(O/\(P/\(Q/\(R/\(S/\(T/\(U/\(V/\(W/\(X/\(Y/\Z)))))))))))))))))))))))))
// test: (A\/(B\/(C\/(D\/(E\/(F\/(G\/(H\/(I\/(J\/(K\/(L\/(M\/(N\/(O\/(P\/(Q\/(R\/(S\/(T\/(U\/(V\/(W\/(X\/(Y\/Z)))))))))))))))))))))))))
// test: ((R~O)~(L~P))
// test: (((Z~O)->(H->T))->(Z~O))
int main()
{
    string input = "";
    string inputToExit = "exit";
    string inputToStartPreloadedTests = "0";
    string inputToStartTautologyTester = "1";
    string inputToStartUserTest = "2";
    while (input != inputToExit) {
        printf("enter %s to launch preloaded tests;\nenter %s to launch tautology tester;\nenter %s to test yourself;\nenter %s to exit.\n>>>", inputToStartPreloadedTests.c_str(), inputToStartTautologyTester.c_str(), inputToStartUserTest.c_str(), inputToExit.c_str());
        getline(cin, input);
        if (input == inputToExit) {
            printf("requested exit..\n");
            continue;
        }
        if (input == "") {
            continue;
        }
        if (input == inputToStartPreloadedTests) {
            startPreloadedTests();
        }
        if (input == inputToStartTautologyTester) {
            startTautologyTester();
        }
        if (input == inputToStartUserTest) {
            printf("This option is under construction. Please try again later\n");
        }
    }
}

void startPreloadedTests() {
    FormulaRecognizer formulaRecognizer = FormulaRecognizer();
    TautologyRecognizer tautologyRecognizer = TautologyRecognizer();
    vector<string> testFormulas;
    testFormulas.push_back("((A/\\B)\\/((!A)/\\B))");
    testFormulas.push_back("(((((((((((((((((((((((((A\\/B)\\/C)\\/D)\\/E)\\/F)\\/G)\\/H)\\/I)\\/J)\\/K)\\/L)\\/M)\\/N)\\/O)\\/P)\\/Q)\\/R)\\/S)\\/T)\\/U)\\/V)\\/W)\\/X)\\/Y)\\/Z)");
    testFormulas.push_back("(((((((((((((((((((((((((A/\\B)/\\C)/\\D)/\\E)/\\F)/\\G)/\\H)/\\I)/\\J)/\\K)/\\L)/\\M)/\\N)/\\O)/\\P)/\\Q)/\\R)/\\S)/\\T)/\\U)/\\V)/\\W)/\\X)/\\Y)/\\Z)");
    testFormulas.push_back("((!A)\\/B)");
    testFormulas.push_back("((R~O)~(L~P))");
    testFormulas.push_back("A");
    testFormulas.push_back("((!A)\\/((!B)\\/(A/\\B)))");
    testFormulas.push_back("((A/\\B)->(B/\\A))");
    testFormulas.push_back("(A->A)");
    testFormulas.push_back("(A->(A/\\A))");
    testFormulas.push_back("(A->(A~A))");
    testFormulas.push_back("((A/\\A)~A)");
    testFormulas.push_back("((A\\/B)->(B\\/A))");
    testFormulas.push_back("((A/\\B)->(B/\\A))");
    testFormulas.push_back("(!(A/\\(!A)))");
    testFormulas.push_back("(A~A)");
    testFormulas.push_back("(A\\/(!A))");
    testFormulas.push_back("(A->(!(!A)))");
    testFormulas.push_back("((A->(B->C))->((A/\\B)->C))");
    testFormulas.push_back("(((A/\\B)->C)->(A->(B->C)))");
    testFormulas.push_back("(B->((!B)->Z))");
    testFormulas.push_back("(((A->B)/\\(B->C))->(A->C))");
    testFormulas.push_back("(A->(B->A))");
    testFormulas.push_back("((A->B)->((A->(B->C))->(A->C)))");
    testFormulas.push_back("(A->(B->(A/\\B)))");
    testFormulas.push_back("((A/\\B)->A)");
    testFormulas.push_back("((A/\\B)->B)");
    testFormulas.push_back("(A->(A\\/B))");
    testFormulas.push_back("(B->(A\\/B))");
    testFormulas.push_back("((A->C)->((B->C)->((A\\/B)->C)))");
    testFormulas.push_back("((A->B)->((A->(!B))->(!A)))");
    testFormulas.push_back("((!(!A))->A)");
    testFormulas.push_back("((A->B)->((B->A)->(A~B)))");
    testFormulas.push_back("((A->B)->((B->A)->(B~A)))");
    testFormulas.push_back("((A->B)->((B->A)->(A~A)))");
    testFormulas.push_back("((A->B)->((B->A)->(B~B)))");
    testFormulas.push_back("((A~B)->(B->A))");
    testFormulas.push_back("((A~B)->(A->A))");
    testFormulas.push_back("((A~B)->(A->B))");
    testFormulas.push_back("((A~B)->(B->B))");
    testFormulas.push_back("(((Z~O)->(H->T))->(((Z~O)->((H->T)->((!R)->W)))->((Z~O)->((!R)->W))))");
    testFormulas.push_back("(!(A\\/(!A)))");
    testFormulas.push_back("((P\\/(P/\\Q))~(!P))");
    testFormulas.push_back("(!(P->(P->(Q~Q))))");
    for (int i = 0; i < testFormulas.size() && formulaRecognizer.isFormula(testFormulas[i]); i++) {
        string test = testFormulas[i];
        printf("%s is%s tautology\n", test.c_str(), (tautologyRecognizer.isTautology(test)) ? "" : " not");
    }
}

void startTautologyTester() {
    FormulaRecognizer formulaRecognizer = FormulaRecognizer();
    TautologyRecognizer tautologyRecognizer = TautologyRecognizer();
    string input = "";
    string valueToExit = "exit";
    while (input != valueToExit) {
        printf("enter formula to check whether it is tautology or enter %s to exit\n", valueToExit.c_str());
        getline(cin, input);
        if (input==valueToExit || input=="") {
            continue;
        }
        if (!formulaRecognizer.isFormula(input)) {
            printf("%s is not a formula\n", input.c_str());
            continue;
        }
        printf("%s is%s tautology\n", input.c_str(), (tautologyRecognizer.isTautology(input)) ? "" : " not");
    }
}