////////////////////////////////////////////
//Лабораторная работа №1 по дисциплине ЛОИС
//Выполнена студентами группы 921704
//Гнуда Илья Сергеевич
//Шевчук Андрей Вадимович
//16.03.2022 - Написание кода, версия 1.0.0
//Вариант С(Проверить является ли формула совершенной конъюнктивной нормальной формой(СКНФ))
//Использованные источники:
//1) Справочно проверяющая семантическая система по дисциплине ЛОИС
//   Сслыка: http://scnedu.sourceforge.net/variety/_/index.html?variety=examinator.PSMIS.E.1.json

package com.company;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
public class Main {
    public static final List<String> NUMBERS=new ArrayList<>(Arrays.asList("0","1","2","3","4","5","6","7","8","9"));
    public static final List<String> SYMBOLS = new ArrayList<>(Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"));
    public static final List<String> SIGNS = new ArrayList<>(Arrays.asList("/\\", "\\/", "->", "~"));
    private static final String PATH = "D:\\JavaPr\\untitled5\\input2.txt";
    private static final String MAIN_SIGN="/\\\\";
    public static void main(String[] args) throws Exception {
        try {
            List<String> br = Files.readAllLines(Path.of(PATH), StandardCharsets.UTF_8);
            for (String line : br) {
                System.out.println(line);
                TryCheckFormula(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        TryCheckFormula("(!A)");
        TryCheckFormula("((A\\/(B\\/C))/\\(((!A)\\/(B\\/C))/\\(A\\/(B\\/(!C)))))");
        TryCheckFormula("B");


    }
    // Метод разработал Гнуда Илья
    public static void CorrectBrackets(String formula) throws Exception {
            if(formula.contains(")("))
                throw  new Exception("Formula contains )(");
            if(formula.charAt(0)!='(' || formula.charAt(formula.length()-1)!=')')
                throw new Exception("Incorrect start or end brackets");
            int countBrackets=0;
            for(int i=0;i<formula.length();i++){
                if(formula.charAt(i)=='(')
                    countBrackets++;
                else if(formula.charAt(i)==')')
                    countBrackets--;
                if(countBrackets==0 && i!=formula.length()-1)
                    throw new Exception("Incorrect brackets");}
            if(countBrackets!=0)
                throw new Exception("Incorrect brackets");
    }

    // Метод разработал Гнуда Илья
    public static void TryCheckFormula(String formula){
        try{

            if(formula.contains(" ") || formula.isEmpty())
                throw  new Exception("Formula couldn't be empty or contain spaces");
            String line =RemoveBrackets(formula);
            if(!IsUnaryOperation(line)) {
                CorrectBrackets(formula);
                CheckNegotationBinOperation(formula);

                CheckCorrectFormula(formula);
                CheckSKNF(formula);}
            else{
                if(formula.length()!=1 && SYMBOLS.contains(""+line.charAt(0))){
                    throw new Exception("Brackets isn't required");
                }
                if(line.charAt(0)=='!' && !(formula.charAt(0)=='(')){
                    throw new Exception("Brackets isn't required");
                }

            }

            System.out.println(formula+ " formula correct.It's a PCNF");
        }
        catch (Exception e ){
            System.out.println(formula+ " formula is incorrect, cause of:" + e.getMessage());
        }

    }
    // Метод разработал Шевчук Андрей
    private static boolean IsUnaryOperation(String formula) throws Exception {
        for (String number : NUMBERS) {
            if (formula.contains("" + number)){
                throw new Exception("There is a number in operand");
            }
        }
        if(formula.charAt(0)=='!'){
            formula=formula.substring(1);
        }
        return formula.length() == 1;
    }
    // Метод разработал Шевчук Андрей
    private static void CheckBinaryOperation(String formula) throws Exception {
        int countBracket=0;
        int countBin=0;
        for(int i=0;i<formula.length()-1;i++){
            if(formula.charAt(i)=='('){
                countBracket++;
            }
            else if(formula.charAt(i)==')'){
                countBracket--;
            }
            else{
                String str= formula.substring(i,i+2);
                if(countBracket==1 && SIGNS.contains(str)){
                    countBin++;
                }
            }

        }
        if(countBin>1){
            throw new Exception("More than 1 bin operation in bracket");
        }
    }
    // Метод разработал Шевчук Андрей
    private static String LeftPart(String formula) throws Exception {
        int countBracket=0;
        for(int i=0;i<formula.length()-1;i++){
            if(formula.charAt(i)=='('){
                countBracket++;
            }
            else if(formula.charAt(i)==')'){
                countBracket--;
            }
            String str=formula.substring(i,i+2);
            if( SIGNS.contains(str) && countBracket==1){
                return formula.substring(1,i);
            }
        }
        throw new Exception("Couldn't get left part of formula ");
    }
    // Метод разработал Шевчук Андрей
    private static String RightPart(String formula) throws Exception {
        int countBracket=0;
        for(int i=formula.length()-1;i>0;i--){
            if(formula.charAt(i)==')'){
                countBracket++;
            }
            else if(formula.charAt(i)=='('){
                countBracket--;
            }
            String str=formula.substring(i-1,i+1);
            if( SIGNS.contains(str) && countBracket==1){
                return formula.substring(++i,formula.length()-1);
            }
        }
        throw new Exception("Couldn't get right part of formula ");
    }
    // Метод разработал Гнудой Ильей
    private static void CheckSKNF(String formula) throws Exception {
        var list= GetAtomDisjunction(formula);
        EnsureEachDisSameSize(list);
        EnsureNotSameDis(list);
        EnsureAllOperandsInDis(list);
    }
    // Метод разработал Шевчук Андрей
    private static String RemoveBrackets(String formula) {
       if(formula.charAt(0)=='(' && formula.charAt(formula.length()-1)==')'){
           formula=formula.substring(1,formula.length()-1);
       }
       return formula;
    }
    // Метод разработал Шевчук Андрей
    private static boolean CheckCorrectFormula(String formula) throws Exception {
        if(IsUnaryOperation(RemoveBrackets(formula))){
            return true;
        }

        CheckBinaryOperation(formula);

        String leftPart=LeftPart(formula);
        String rightPart=RightPart(formula);

        return (IsUnaryOperation(RemoveBrackets(leftPart))|| CheckCorrectFormula(leftPart)) &&
                (IsUnaryOperation(RemoveBrackets(rightPart))|| CheckCorrectFormula(rightPart));
    }
    // Метод разработал Гнуда Илья
    private static ArrayList<ArrayList<String>> GetAtomDisjunction(String expression) throws Exception{

        if(expression.contains("->") || expression.contains("~")){
            throw new Exception("This isn't  PCNF");
        }
        String str=MAIN_SIGN.strip();
        var list=expression.split(str);
        var res=new ArrayList<ArrayList<String>>(list.length);
        for(int i=0;i<list.length;i++){
            res.add(new ArrayList<>());
        }

        for( int i=0;i<list.length;i++){
            var subFormula=list[i];
            for(int j=0;j<subFormula.length();j++){

                if(SYMBOLS.contains(""+subFormula.charAt(j)) || subFormula.charAt(j)=='!'){

                    int start=j;
                    j++;
                    while(true){
                        if(j> subFormula.length()-1){
                            res.get(i).add(subFormula.substring(start,j));
                            break;
                        }
                        else if(!SYMBOLS.contains(""+subFormula.charAt(j)) && !NUMBERS.contains(""+subFormula.charAt(j))){
                            res.get(i).add(subFormula.substring(start,j));
                            break;
                        }
                        j++;
                    }
                }
            }
        }


        return res;
    }
    // Метод разработал Гнуда Илья
    private static void EnsureEachDisSameSize(ArrayList<ArrayList<String>> list) throws Exception {

        for(int i=0;i<list.size();i++) {
            for(int j=i+1;j<list.size();j++){
                if(list.get(i).size()!=list.get(j).size()){
                    throw new Exception("Incorrect SKNF. Not same number of operands.");
                }
            }
        }
    }
    // Метод разработал Гнуда Илья
    private static void EnsureAllOperandsInDis(ArrayList<ArrayList<String>> list) throws Exception {
        for(int i=0;i<list.size();i++){
            var dis1=list.get(i);
            for(int k=0;k<dis1.size();k++){
                if(dis1.get(k).charAt(0)=='!') {
                    dis1.set(k,dis1.get(k).substring(1));
                }
            }
            if(dis1.size()!= new HashSet<>(dis1).size()){
                throw new Exception("Incorrect SKNF. Have repeat in Dis");
            }
            Collections.sort(dis1);
            for(int j=i+1;j<list.size();j++){
                var dis2=list.get(j);
                for(int z=0;z<dis1.size();z++){
                    if(dis2.get(z).charAt(0)=='!') {
                        dis2.set(z,dis2.get(z).substring(1));
                    }
                }
                Collections.sort(dis2);
                if(!dis1.equals(dis2)){
                    throw new Exception("Incorrect SKNF. Not same operands");
                }
            }
        }
    }
    // Метод разработал Гнуда Илья
    private static void EnsureNotSameDis(ArrayList<ArrayList<String>> list) throws Exception {
        for(int i=0;i<list.size()-1;i++){
            var dis1=list.get(i);
            Collections.sort(dis1);
            for(int j=i+1;j<list.size();j++){
                var dis2=list.get(j);
                Collections.sort(dis2);
                if(dis1.equals(dis2)){
                    throw new Exception("Incorrect SKNF. Two same or more disjunctions");
                }
            }
        }
    }
    // Метод разработал Гнуда Илья
    private static void CheckNegotationBinOperation(String formula) throws Exception {

        for(int i=0;i<formula.length();i++) {
            if (formula.charAt(i) == '!' && !SYMBOLS.contains(""+formula.charAt(i + 1))) {
                throw new Exception("There is negotiation of complex formula");
            }
        }
    }
    /*private static String CheckNegotationBinOperation(String formula) {

        for(int i=0;i<formula.length();i++){
            if(formula.charAt(i)=='!' && formula.charAt(i+1)=='('){
                int countBracket=1;
                int startIndex=i+2;
                while(true){
                    if (formula.charAt(i)=='(')
                        countBracket++;
                    else if(formula.charAt(i)==')')
                        countBracket--;
                    if(countBracket==0)
                        break;
                    i++;
                }
                int endIndex=i;
                String subFormula=formula.substring(startIndex-1,endIndex);
                subFormula =RemoveNegotationBinOperation(subFormula);
                formula=formula.replace(formula.substring(startIndex-3,endIndex+1),subFormula);
                try{
                    CorrectBrackets(formula);
                }
                catch (Exception E){
                    formula=RemoveBrackets(formula);
                }
                i=-1;

            }
        }

        return formula;
    }*/
    /*private static String RemoveNegotationBinOperation(String formula) {
        StringBuilder newStr=new StringBuilder();
        newStr.append("(");
        formula=RemoveBrackets(formula);
        for(int i=0;i<formula.length();i++){
            if(SYMBOLS.contains(""+formula.charAt(i))){
                newStr.append("(!");
                newStr.append(formula.charAt(i));
                newStr.append(")");
            }
            else if(formula.charAt(i)=='(' && formula.charAt(i+1)=='!'){
                int countBracket=1;
                i+=2;
                int startIndex=i;
                while (true) {
                    if (formula.charAt(i)=='(')
                        countBracket++;
                    else if(formula.charAt(i)==')')
                        countBracket--;
                    if(countBracket==0)
                        break;
                    i++;
                }
                newStr.append(formula,startIndex,i);
            }
            else if(formula.charAt(i)=='!'){
                if (SYMBOLS.contains(""+formula.charAt(i+1)))
                {newStr.append(formula.charAt(i+1));}
                i+=1;
            }
            else {
                String s = "" + formula.charAt(i) + formula.charAt(i + 1);
                if(s.equals("/\\")){
                    newStr.append("\\/");
                    i++;
                }
                else if(s.equals("\\/")){
                    newStr.append("/\\");
                    i++;
                }
                else {
                    if(formula.charAt(i)=='(' && formula.charAt(i+1)!='!'){
                        newStr.append("(!");
                        int countBracket=0;
                        while (true){
                            newStr.append(formula.charAt(i));
                            if (formula.charAt(i)=='(')
                                countBracket++;
                            else if(formula.charAt(i)==')')
                                countBracket--;
                            if (countBracket==0)
                                break;
                            i++;

                        }
                        newStr.append(")");
                    }
                }
            }

        }
        newStr.append(")");
        return newStr.toString();
    }*/
}
