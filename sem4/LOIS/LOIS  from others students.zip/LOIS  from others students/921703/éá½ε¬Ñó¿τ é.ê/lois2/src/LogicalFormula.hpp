//////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа 2 по дисциплине ЛОИС
// Выполнена студентом группы 921703
// БГУИР Валюкевич В.И.
// Вариант 1 - Вычислить возможные значения формулы сокращенного языка логики высказываний при частично заданной
// интерпретации формулы (частично заданных значениях пропозиционных переменных). Результат оформить в виде таблицы.
// 02.03.2022
// Использованные материалы:
// https://github.com/fintarin/Fintamath - написанная мной система решения математических выражений

#pragma once

#include <memory>
#include <string>
#include <vector>

class LogicalFormula {
public:
  struct Node {
    std::string info;
    std::shared_ptr<Node> left;
    std::shared_ptr<Node> right;
  };

  LogicalFormula() = default;
  explicit LogicalFormula(const std::string &str);

  void setVariableToTruthTable(const std::string &str);
  std::pair<std::vector<char>, std::vector<std::vector<bool>>> getTruthTable() const;

  std::shared_ptr<Node> &getRoot();

private:
  std::shared_ptr<Node> root = std::make_shared<Node>();
  std::vector<char> variables;
  std::vector<int> values;

  void solve(std::shared_ptr<LogicalFormula::Node> &node,
             const std::pair<std::vector<char>, std::vector<std::vector<bool>>> &truthTable, size_t row) const;
  int getValue(char variable, const std::pair<std::vector<char>, std::vector<std::vector<bool>>> &truthTable,
               size_t row) const;
};
