//////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа 2 по дисциплине ЛОИС
// Выполнена студентом группы 921703
// БГУИР Валюкевич В.И.
// Вариант 1 - Вычислить возможные значения формулы сокращенного языка логики высказываний при частично заданной
// интерпретации формулы (частично заданных значениях пропозиционных переменных). Результат оформить в виде таблицы.
// 02.03.2022
// Использованные материалы:
// https://github.com/fintarin/Fintamath - написанная мной система решения математических выражений

#include "LogicalFormula.hpp"

#include <algorithm>
#include <bitset>
#include <cmath>
#include <stdexcept>
#include <vector>

static std::vector<std::string> makeVectOfTokens(const std::string &inStr, std::vector<char> &variables);
static void makeFormula(const std::vector<std::string> &tokensVect, LogicalFormula &formula);
static void makeFormulaRec(const std::vector<std::string> &tokensVect, std::shared_ptr<LogicalFormula::Node> &node,
                           size_t first, size_t last);

static bool descentBinaryOper(const std::vector<std::string> &tokensVect,
                              const std::shared_ptr<LogicalFormula::Node> &node, size_t begin, size_t end);
static bool descentUnaryOper(const std::vector<std::string> &tokensVect,
                             const std::shared_ptr<LogicalFormula::Node> &node, size_t begin, size_t end);

static void setValues(std::pair<std::vector<char>, std::vector<std::vector<bool>>> &truthTable);
static void copy(const std::shared_ptr<LogicalFormula::Node> &src, std::shared_ptr<LogicalFormula::Node> &dest);

static bool isTrueFalse(char ch);
static bool isLetter(char ch);
static bool isTerm(const std::string &str);
static bool isBinaryOperator(const std::string &str);
static bool isUnaryOperator(const std::string &str);

LogicalFormula::LogicalFormula(const std::string &str) {
  makeFormula(makeVectOfTokens(str, variables), *this);
  values = std::vector<int>(variables.size(), -1);
}

void LogicalFormula::setVariableToTruthTable(const std::string &str) {
  if (str.size() != 3 || !isLetter(str[0]) || str[1] != '=' || !isTrueFalse(str[2])) {
    throw std::invalid_argument("Переменная задана неверно");
  }

  size_t i = std::distance(std::begin(variables), std::find(std::begin(variables), std::end(variables), str[0]));
  if (i >= variables.size()) {
    throw std::invalid_argument("Переменная задана неверно");
  }

  values[i] = int(str[2] - '0');
}

std::pair<std::vector<char>, std::vector<std::vector<bool>>> LogicalFormula::getTruthTable() const {
  std::pair<std::vector<char>, std::vector<std::vector<bool>>> truthTable = {variables, {}};

  for (int64_t i = 0, j = 0; i < variables.size(); i++, j++) {
    if (values[i] != -1) {
      truthTable.first.erase(truthTable.first.begin() + j);
      j--;
    }
  }

  setValues(truthTable);
  truthTable.first.push_back('=');

  for (size_t i = 0; i < truthTable.second.size(); i++) {
    LogicalFormula formula;
    copy(root, formula.root);
    solve(formula.root, truthTable, i);
    truthTable.second[i].push_back(bool(std::stoi(formula.root->info)));
  }

  return truthTable;
}

std::shared_ptr<LogicalFormula::Node> &LogicalFormula::getRoot() {
  return root;
}

void LogicalFormula::solve(std::shared_ptr<LogicalFormula::Node> &node,
                           const std::pair<std::vector<char>, std::vector<std::vector<bool>>> &truthTable,
                           size_t row) const {
  if (node->right != nullptr) {
    solve(node->right, truthTable, row);
  }
  if (node->left != nullptr) {
    solve(node->left, truthTable, row);
  }

  if (isLetter(node->info[0])) {
    node->info = std::to_string(getValue(node->info[0], truthTable, row));
  } else {
    bool rhs = false;
    if (node->right != nullptr) {
      rhs = bool(std::stol(node->right->info));
    }

    bool lhs = false;
    if (node->left != nullptr) {
      lhs = bool(std::stol(node->left->info));
    }

    if (node->info == "!") {
      node->info = std::to_string(size_t(!rhs));
    } else if (node->info == R"(/\)") {
      node->info = std::to_string(size_t(lhs && rhs));
    } else if (node->info == R"(\/)") {
      node->info = std::to_string(size_t(lhs || rhs));
    } else if (node->info == "->") {
      node->info = std::to_string(size_t((!lhs) || rhs));
    } else if (node->info == "~") {
      node->info = std::to_string(size_t(lhs == rhs));
    }
  }
}

int LogicalFormula::getValue(char variable,
                             const std::pair<std::vector<char>, std::vector<std::vector<bool>>> &truthTable,
                             size_t row) const {
  {
    size_t i = std::distance(std::begin(variables), std::find(std::begin(variables), std::end(variables), variable));
    int val = values[i];
    if (val != -1) {
      return val;
    }
  }
  {
    size_t i = std::distance(std::begin(truthTable.first),
                             std::find(std::begin(truthTable.first), std::end(truthTable.first), variable));
    return int(truthTable.second[row][i]);
  }
}

static std::vector<std::string> makeVectOfTokens(const std::string &inStr, std::vector<char> &variables) {
  std::string str = inStr;
  std::vector<std::string> tokensVect;

  size_t bracketsNum = 0;
  size_t operatorsNum = 0;
  bool wasBracket = false;

  for (size_t i = 0; i < str.size(); i++) {
    if (isTrueFalse(str[i])) {
      tokensVect.emplace_back(std::string(1, str[i]));
    } else if (isLetter(str[i])) {
      if (std::find(std::begin(variables), std::end(variables), str[i]) == std::end(variables)) {
        variables.push_back(str[i]);
      }
      tokensVect.emplace_back(std::string(1, str[i]));
    } else if (str[i] == ')') {
      tokensVect.emplace_back(std::string(1, str[i]));
      wasBracket = true;
    } else if (str[i] == '(') {
      tokensVect.emplace_back(std::string(1, str[i]));
      wasBracket = true;
      bracketsNum++;
    } else {
      bool isFormulaCorrect = false;

      for (size_t j = 1; j <= 2; j++) {
        if (auto oper = str.substr(i, j); isUnaryOperator(oper) || isBinaryOperator(oper)) {
          if (!wasBracket) {
            throw std::invalid_argument("Формула введена неверно");
          }

          tokensVect.emplace_back(std::string(oper));
          wasBracket = false;
          operatorsNum++;

          isFormulaCorrect = true;
          i += j - 1;
          break;
        }
      }

      if (!isFormulaCorrect) {
        throw std::invalid_argument("Формула введена неверно");
      }
    }
  }

  if (operatorsNum != bracketsNum) {
    throw std::invalid_argument("Формула введена неверно");
  }

  return tokensVect;
}

static void makeFormula(const std::vector<std::string> &tokensVect, LogicalFormula &formula) {
  if (tokensVect.empty()) {
    throw std::invalid_argument("Формула введена неверно");
  }
  makeFormulaRec(tokensVect, formula.getRoot(), 0, tokensVect.size() - 1);
}

static void makeFormulaRec(const std::vector<std::string> &tokensVect, std::shared_ptr<LogicalFormula::Node> &node,
                           size_t first, size_t last) {
  if (first > last || last == SIZE_MAX) {
    throw std::invalid_argument("Формула введена неверно");
  }
  if (node == nullptr) {
    node = std::make_shared<LogicalFormula::Node>();
  }
  if (descentBinaryOper(tokensVect, node, first, last)) {
    return;
  }
  if (descentUnaryOper(tokensVect, node, first, last)) {
    return;
  }
  if (first == last) {
    node->info = tokensVect[first];
    return;
  }
  if (tokensVect[first] == "(" && tokensVect[last] == ")") {
    makeFormulaRec(tokensVect, node, first + 1, last - 1);
  }
  if (node->info.empty()) {
    throw std::invalid_argument("Формула введена неверно");
  }
}

static bool descentBinaryOper(const std::vector<std::string> &tokensVect,
                              const std::shared_ptr<LogicalFormula::Node> &node, size_t begin, size_t end) {
  size_t bracketsNum = 0;

  for (size_t i = begin; i <= end; i++) {
    if (tokensVect[i] == "(") {
      bracketsNum++;
    } else if (tokensVect[i] == ")") {
      if (bracketsNum == 0) {
        throw std::invalid_argument("Формула введена неверно");
      }
      bracketsNum--;
    }

    if (bracketsNum == 0 && isBinaryOperator(tokensVect[i])) {
      node->info = tokensVect[i];
      makeFormulaRec(tokensVect, node->right, i + 1, end);
      makeFormulaRec(tokensVect, node->left, begin, i - 1);
      return true;
    }
  }

  return false;
}

static bool descentUnaryOper(const std::vector<std::string> &tokensVect,
                             const std::shared_ptr<LogicalFormula::Node> &node, size_t begin, size_t end) {
  if (isUnaryOperator(tokensVect[begin])) {
    node->info = tokensVect[begin];
    makeFormulaRec(tokensVect, node->right, begin + 1, end);
    return true;
  }
  return false;
}

static void setValues(std::pair<std::vector<char>, std::vector<std::vector<bool>>> &truthTable) {
  constexpr size_t BASE = 64;

  truthTable.second.resize(size_t(std::pow(2, truthTable.first.size())));
  for (size_t i = 0; i < truthTable.second.size(); i++) {
    truthTable.second[i].resize(truthTable.first.size());
    auto binary = std::bitset<BASE>(i).to_string();

    for (size_t j = 0; j < truthTable.first.size(); j++) {
      truthTable.second[i][truthTable.first.size() - j - 1] = binary[BASE - j - 1] == '1';
    }
  }
}

static void copy(const std::shared_ptr<LogicalFormula::Node> &src, std::shared_ptr<LogicalFormula::Node> &dest) {
  if (src->right != nullptr) {
    dest->right = std::make_shared<LogicalFormula::Node>();
    copy(src->right, dest->right);
  }
  if (src->left != nullptr) {
    dest->left = std::make_shared<LogicalFormula::Node>();
    copy(src->left, dest->left);
  }

  dest->info = src->info;
}

static bool isTrueFalse(char ch) {
  return (ch == '0' || ch == '1');
}

static bool isLetter(char ch) {
  return (ch >= 'A' && ch <= 'Z');
}

static bool isTerm(const std::string &str) {
  return isTrueFalse(str[0]) || isLetter(str[0]);
}

static bool isBinaryOperator(const std::string &str) {
  return (str == R"(/\)" || str == R"(\/)" || str == "->" || str == "~");
}

static bool isUnaryOperator(const std::string &str) {
  return str == "!";
}
