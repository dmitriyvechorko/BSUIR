//////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа 2 по дисциплине ЛОИС
// Выполнена студентом группы 921703
// БГУИР Валюкевич В.И.
// Вариант 1 - Вычислить возможные значения формулы сокращенного языка логики высказываний при частично заданной
// интерпретации формулы (частично заданных значениях пропозиционных переменных). Результат оформить в виде таблицы.
// 02.03.2022
// Использованные материалы:
// https://github.com/fintarin/Fintamath - написанная мной система решения математических выражений

#include <algorithm>
#include <fstream>
#include <iostream>
#include <vector>

#include "LogicalFormula.hpp"

static void runSolverMode();
static void runKnowledgeTestMode();
static void runTests();

static LogicalFormula getFormula(const std::string &str);
static void readTable(std::ifstream &stream, std::pair<std::vector<char>, std::vector<std::vector<bool>>> &table);
static void printTable(const std::pair<std::vector<char>, std::vector<std::vector<bool>>> &table);

static size_t getAllTrueVals(const std::vector<std::vector<bool>> &table);

int main() {
  while (true) {
    std::cout << "Выберите режим работы\n";
    std::cout << "0 - решатель\n";
    std::cout << "1 - тестирование знаний\n";
    std::cout << "2 - тестирование решателя\n";
    std::cout << "3 - выход из программы\n";

    std::string str;
    std::getline(std::cin, str);
    std::cout << "\n";

    if (str == "0") {
      runSolverMode();
    } else if (str == "1") {
      runKnowledgeTestMode();
    } else if (str == "2") {
      runTests();
    } else if (str == "3") {
      break;
    }
  }
}

static void runSolverMode() {
  while (true) {
    std::cout << "Введите формулу или \"exit\" для выхода из решателя\n";
    std::string str;
    std::getline(std::cin, str);

    if (str == "exit") {
      std::cout << "\n";
      break;
    }

    try {
      auto table = getFormula(str).getTruthTable();
      std::cout << "Таблица истинности:\n";
      printTable(table);
      std::cout << "\n\n";
    } catch (const std::invalid_argument &exc) {
      std::cout << exc.what() << "\n\n";
    }
  }
}

static void runKnowledgeTestMode() {
  std::ifstream testsIn(RESOURCES_DIR "knowledge_tests.txt");

  std::vector<std::string> tests;
  for (std::string input; getline(testsIn, input);) {
    tests.push_back(input);
  }

  size_t correctAnswersNum = 0;

  for (const auto &test : tests) {
    std::cout << "На скольких интерпретациях формула принимает значение \"истина\"?\n" + test << '\n';
    std::string str;
    std::getline(std::cin, str);
    std::cout << "\n";

    std::string res;
    try {
      res = std::to_string(getAllTrueVals(getFormula(test).getTruthTable().second));
    } catch (const std::invalid_argument &) {
      continue;
    }

    if (str == res) {
      correctAnswersNum++;
    }
  }

  std::cout << "Результат: верно " + std::to_string(correctAnswersNum) + " из " + std::to_string(tests.size())
            << "\n\n";
}

static void runTests() {
  std::ifstream testsIn(RESOURCES_DIR "positive_tests.txt");
  for (std::string input, output; getline(testsIn, input);) {
    try {
      std::pair<std::vector<char>, std::vector<std::vector<bool>>> table;
      readTable(testsIn, table);
      if (table != getFormula(input).getTruthTable()) {
        std::cout << "Позитивный тест " + input + " не пройден\n\n";
      }
    } catch (...) {
      std::cout << "Позитивный тест " + input + " не пройден\n\n";
      return;
    }
  }

  testsIn = std::ifstream(RESOURCES_DIR "negative_tests.txt");
  for (std::string input; getline(testsIn, input);) {
    try {
      getFormula(input);
      std::cout << "Негативный тест " + input + " не пройден\n\n";
      return;
    } catch (...) {
    }
  }

  std::cout << "Все тесты пройдены\n\n";
}

static LogicalFormula getFormula(const std::string &str) {
  auto firstComma = std::distance(std::begin(str), std::find(str.begin(), std::end(str), ','));
  LogicalFormula formula(std::string(str.begin(), str.begin() + firstComma));
  for (size_t i = firstComma + 1; i < str.size(); i += 4) {
    formula.setVariableToTruthTable(str.substr(i, 3));
  }
  return formula;
}

static void readTable(std::ifstream &stream, std::pair<std::vector<char>, std::vector<std::vector<bool>>> &table) {
  std::string str;
  getline(stream, str);
  for (auto ch : str) {
    if (ch != ' ') {
      table.first.push_back(ch);
    }
  }

  while (getline(stream, str)) {
    if (str.empty()) {
      return;
    }

    table.second.resize(table.second.size() + 1);

    for (auto ch : str) {
      if (ch != ' ') {
        table.second.back().push_back(ch != '0');
      }
    }
  }
}

static void printTable(const std::pair<std::vector<char>, std::vector<std::vector<bool>>> &table) {
  for (const auto &val : table.first) {
    std::cout << val << " ";
  }
  std::cout << "\n";
  for (const auto &row : table.second) {
    for (auto val : row) {
      std::cout << val << " ";
    }
    std::cout << "\n";
  }
}

static size_t getAllTrueVals(const std::vector<std::vector<bool>> &table) {
  size_t res = 0;
  for (const auto &row : table) {
    if (row.back()) {
      res++;
    }
  }
  return res;
}

// ((((((((((((((((((((((((A\/B)\/C)\/D)\/E)\/F)\/G)\/H)\/I)\/J)\/K)\/L)\/M)\/N)\/O)\/P)\/Q)\/R)\/S)\/T)\/U)\/V)\/W)\/X)\/Y)
// ((((((((((((((((((((((((A/\B)/\C)/\D)/\E)/\F)/\G)/\H)/\I)/\J)/\K)/\L)/\M)/\N)/\O)/\P)/\Q)/\R)/\S)/\T)/\U)/\V)/\W)/\X)/\Y)
