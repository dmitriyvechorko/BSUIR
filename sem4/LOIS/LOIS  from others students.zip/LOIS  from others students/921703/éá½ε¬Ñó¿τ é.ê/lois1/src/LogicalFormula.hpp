//////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа 1 по дисциплине ЛОИС
// Выполнена студентом группы 921703
// БГУИР Валюкевич В.И.
// Вариант 1 - Подсчитать количество подформул в формуле сокращенного языка логики высказываний
// 16.02.2022
// Использованные материалы:
// https://github.com/fintarin/Fintamath - написанная мной система решения математических выражений

#pragma once

#include <memory>
#include <string>

class LogicalFormula {
public:
  struct Node {
    std::string info;
    std::shared_ptr<Node> left;
    std::shared_ptr<Node> right;
  };

  LogicalFormula() = default;
  explicit LogicalFormula(const std::string &str);

  std::shared_ptr<Node> &getRoot();

private:
  std::shared_ptr<Node> root = std::make_shared<Node>();
};
