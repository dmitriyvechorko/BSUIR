// ////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа 1 по дисциплине ЛОИС
// Выполнена студентом группы 921703
// БГУИР Валюкевич В.И.
// Вариант 1 - Подсчитать количество подформул в формуле сокращенного языка логики высказываний
// 16.02.2022
// Использованные материалы:
// https://github.com/fintarin/Fintamath - написанная мной система решения математических выражений

#include <algorithm>
#include <fstream>
#include <iostream>
#include <vector>

#include "LogicalFormula.hpp"

static size_t solveSubFormulaCount(const std::string &str);
static void solveSubFormulaCountRec(const std::shared_ptr<LogicalFormula::Node> &node, size_t &count);

static void runSolverMode();
static void runKnowledgeTestMode();
static void runTests();

int main() {
  while (true) {
    std::cout << "Выберите режим работы\n";
    std::cout << "0 - решатель\n";
    std::cout << "1 - тестирование знаний\n";
    std::cout << "2 - тестирование решателя\n";
    std::cout << "3 - выход из программы\n";

    std::string str;
    std::getline(std::cin, str);
    std::cout << "\n";

    if (str == "0") {
      runSolverMode();
    } else if (str == "1") {
      runKnowledgeTestMode();
    } else if (str == "2") {
      runTests();
    } else if (str == "3") {
      break;
    }
  }
}

static size_t solveSubFormulaCount(const std::string &str) {
  size_t count = 0;
  LogicalFormula formula(str);
  solveSubFormulaCountRec(formula.getRoot(), count);
  return count;
}

static void solveSubFormulaCountRec(const std::shared_ptr<LogicalFormula::Node> &node, size_t &count) {
  if (node->right != nullptr) {
    solveSubFormulaCountRec(node->right, count);
  }
  if (node->left != nullptr) {
    solveSubFormulaCountRec(node->left, count);
  }

  count++;
}

static void runSolverMode() {
  while (true) {
    std::cout << "Введите формулу или \"exit\" для выхода из решателя\n";
    std::string str;
    std::getline(std::cin, str);

    if (str == "exit") {
      std::cout << "\n";
      break;
    }

    try {
      auto res = solveSubFormulaCount(str);
      std::cout << "Количество подформул = " << res << "\n\n";
    } catch (const std::invalid_argument &) {
      std::cout << "Формула введена неверно\n\n";
    }
  }
}

static void runKnowledgeTestMode() {
  std::ifstream testsIn(RESOURCES_DIR "knowledge_tests.txt");

  std::vector<std::string> tests;
  for (std::string input; getline(testsIn, input);) {
    tests.push_back(input);
  }

  int correctAnswersNum = 0;

  for (const auto &test : tests) {
    std::cout << "Найдите количество подформул в формуле: " + test << '\n';
    std::string str;
    std::getline(std::cin, str);
    std::cout << "\n";

    std::string res;
    try {
      res = std::to_string(solveSubFormulaCount(str));
    } catch (const std::invalid_argument &) {
      continue;
    }

    if (test == res) {
      correctAnswersNum++;
    }
  }

  std::cout << "Результат: верно " + std::to_string(correctAnswersNum) + " из " + std::to_string(tests.size())
            << "\n\n";
}

static void runTests() {
  std::ifstream testsIn(RESOURCES_DIR "positive_tests.txt");
  for (std::string input, output; getline(testsIn, input) && getline(testsIn, output);) {
    try {
      if (std::to_string(solveSubFormulaCount(input)) != output) {
        std::cout << "Позитивный тест " + input + " не пройден\n\n";
        return;
      }
    } catch (...) {
      std::cout << "Позитивный тест " + input + " не пройден\n\n";
      return;
    }
    getline(testsIn, input);
  }

  testsIn = std::ifstream(RESOURCES_DIR "negative_tests.txt");
  for (std::string input; getline(testsIn, input);) {
    try {
      solveSubFormulaCount(input);
      std::cout << "Негативный тест " + input + " не пройден\n\n";
      return;
    } catch (...) {
    }
  }

  std::cout << "Все тесты пройдены\n\n";
}