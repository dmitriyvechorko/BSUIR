//////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа 1 по дисциплине ЛОИС
// Выполнена студентом группы 921703
// БГУИР Валюкевич В.И.
// Вариант 1 - Подсчитать количество подформул в формуле сокращенного языка логики высказываний
// 16.02.2022
// Использованные материалы:
// https://github.com/fintarin/Fintamath - написанная мной система решения математических выражений

#include "LogicalFormula.hpp"

#include <algorithm>
#include <stdexcept>
#include <vector>

static std::vector<std::string> makeVectOfTokens(const std::string &inStr);
static LogicalFormula makeFormula(const std::vector<std::string> &tokensVect);
static void makeFormulaRec(const std::vector<std::string> &tokensVect, std::shared_ptr<LogicalFormula::Node> &node,
                           size_t first, size_t last);

static bool descentBinaryOper(const std::vector<std::string> &tokensVect,
                              const std::shared_ptr<LogicalFormula::Node> &node, size_t begin, size_t end);
static bool descentUnaryOper(const std::vector<std::string> &tokensVect,
                             const std::shared_ptr<LogicalFormula::Node> &node, size_t begin, size_t end);

static bool isTrueFalse(char ch);
static bool isLetter(char ch);
static bool isBinaryOperator(const std::string &str);
static bool isUnaryOperator(const std::string &str);

LogicalFormula::LogicalFormula(const std::string &str) {
  *this = makeFormula(makeVectOfTokens(str));
}

std::shared_ptr<LogicalFormula::Node> &LogicalFormula::getRoot() {
  return root;
}

static std::vector<std::string> makeVectOfTokens(const std::string &inStr) {
  std::string str = inStr;
  std::vector<std::string> tokensVect;

  size_t bracketsNum = 0;
  size_t operatorsNum = 0;
  bool wasBracket = false;

  for (size_t i = 0; i < str.size(); i++) {
    if (isTrueFalse(str[i]) || isLetter(str[i])) {
      tokensVect.emplace_back(std::string(1, str[i]));
    } else if (str[i] == ')') {
      tokensVect.emplace_back(std::string(1, str[i]));
      wasBracket = true;
    } else if (str[i] == '(') {
      tokensVect.emplace_back(std::string(1, str[i]));
      wasBracket = true;
      bracketsNum++;
    } else {
      for (size_t j = 1; j <= 2; j++) {
        if (auto oper = str.substr(i, j); isUnaryOperator(oper) || isBinaryOperator(oper)) {
          if (!wasBracket) {
            throw std::invalid_argument("");
          }

          tokensVect.emplace_back(std::string(oper));
          wasBracket = false;
          operatorsNum++;
        }
      }
    }
  }

  if (operatorsNum != bracketsNum) {
    throw std::invalid_argument("");
  }

  return tokensVect;
}

static LogicalFormula makeFormula(const std::vector<std::string> &tokensVect) {
  if (tokensVect.empty()) {
    throw std::invalid_argument("");
  }

  LogicalFormula formula;
  makeFormulaRec(tokensVect, formula.getRoot(), 0, tokensVect.size() - 1);

  return formula;
}

static void makeFormulaRec(const std::vector<std::string> &tokensVect, std::shared_ptr<LogicalFormula::Node> &node,
                           size_t first, size_t last) {
  if (first > last || last == SIZE_MAX) {
    throw std::invalid_argument("");
  }
  if (node == nullptr) {
    node = std::make_shared<LogicalFormula::Node>();
  }
  if (descentBinaryOper(tokensVect, node, first, last)) {
    return;
  }
  if (descentUnaryOper(tokensVect, node, first, last)) {
    return;
  }
  if (first == last) {
    node->info = tokensVect[first];
    return;
  }
  if (tokensVect[first] == "(" && tokensVect[last] == ")") {
    makeFormulaRec(tokensVect, node, first + 1, last - 1);
  }
  if (node->info.empty()) {
    throw std::invalid_argument("");
  }
}

static bool descentBinaryOper(const std::vector<std::string> &tokensVect,
                              const std::shared_ptr<LogicalFormula::Node> &node, size_t begin, size_t end) {
  size_t bracketsNum = 0;

  for (size_t i = begin; i <= end; i++) {
    if (tokensVect[i] == "(") {
      bracketsNum++;
    } else if (tokensVect[i] == ")") {
      if (bracketsNum == 0) {
        throw std::invalid_argument("");
      }
      bracketsNum--;
    }

    if (bracketsNum == 0 && isBinaryOperator(tokensVect[i])) {
      node->info = tokensVect[i];
      makeFormulaRec(tokensVect, node->right, i + 1, end);
      makeFormulaRec(tokensVect, node->left, begin, i - 1);
      return true;
    }
  }

  return false;
}

static bool descentUnaryOper(const std::vector<std::string> &tokensVect,
                             const std::shared_ptr<LogicalFormula::Node> &node, size_t begin, size_t end) {
  if (isUnaryOperator(tokensVect[begin])) {
    node->info = tokensVect[begin];
    makeFormulaRec(tokensVect, node->right, begin + 1, end);
    return true;
  }
  return false;
}

static bool isTrueFalse(char ch) {
  return (ch == '0' || ch == '1');
}

static bool isLetter(char ch) {
  return (ch >= 'A' && ch <= 'Z');
}

static bool isBinaryOperator(const std::string &str) {
  return (str == R"(/\)" || str == R"(\/)" || str == "->" || str == "~");
}

static bool isUnaryOperator(const std::string &str) {
  return str == "!";
}
