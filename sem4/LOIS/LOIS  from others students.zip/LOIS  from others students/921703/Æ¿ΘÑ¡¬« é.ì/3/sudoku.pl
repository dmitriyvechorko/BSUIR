
%///////////////////////////////////////////////////////////////////////////////////////////////////////////////
%// Лабораторная работа №3 по дисциплине Логические Основы Интеллектуальных Систем
%// Выполнена студентом группы 921703 БГУИР Тищенко Виталием Николаевичем
%// Файл sudoku.pl содержит реализацию программы, предназначенной для решения задачи нахождения решения судоку
%// 11.05.2022
%//
%// https://www.youtube.com/watch?v=5KUdEZTu06o - видео с объяснением задачи



:- use_module(library(clpfd)).

sudoku(Rows) :-
    nonvar(Rows),
    noIllegalCharacters(Rows),
    rowsAreFine(Rows),
    columnsAreFine(Rows),
    squaresAreFine(Rows).

noIllegalCharacters(Rows) :-
    append(Rows, Vs), 
    Vs ins 1..9.

rowsAreFine(Rows) :-
    length(Rows, 9),
    maplist(all_distinct, Rows).

columnsAreFine(Rows) :-
    transpose(Rows, Columns), 
    length(Columns, 9),
    maplist(all_distinct, Columns).

squaresAreFine(Rows) :-
    Rows = [As,Bs,Cs,Ds,Es,Fs,Gs,Hs,Is],
    blocks(As, Bs, Cs), 
    blocks(Ds, Es, Fs), 
    blocks(Gs, Hs, Is).

blocks([], [], []).
blocks([N1,N2,N3|Ns1], [N4,N5,N6|Ns2], [N7,N8,N9|Ns3]) :-
        all_distinct([N1,N2,N3,N4,N5,N6,N7,N8,N9]),
        blocks(Ns1, Ns2, Ns3).

problem(1, P) :-
    var(P),
    P = [[1,_,_,8,_,4,_,_,_],
         [_,2,_,_,_,_,4,5,6],
         [_,_,3,2,_,5,_,_,_],
         [_,_,_,4,_,_,8,_,5],
         [7,8,9,_,5,_,_,_,_],
         [_,_,_,_,_,6,2,_,3],
         [8,_,1,_,_,_,7,_,_],
         [_,_,_,1,2,3,_,8,_],
         [2,_,5,_,_,_,_,_,9]].
problem(2, P) :-
    var(P),
    P = [[1,_,4,_,7,_,_,_,_],
         [_,2,_,5,_,_,_,_,_],
         [_,_,3,_,6,_,_,_,_],
         [_,_,_,4,_,_,_,_,_],
         [_,_,_,_,5,_,8,_,_],
         [_,_,_,_,_,6,_,9,_],
         [_,_,_,_,_,_,7,_,1],
         [_,_,_,_,_,_,_,8,_],
         [_,_,_,_,_,_,_,_,9]].


/** <examples>
?- (problem(1, Rows), sudoku(Rows), maplist(label, Rows))
*/
