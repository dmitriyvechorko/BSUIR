
////////////////////////////////////////////////////////////////////////////////////
// ������������ ������ �2 �� ���������� ���������� ������ ���������������� ������
// ��������� ��������� ������ 921703 ����� ������� �������� ������������
// ���� TautologyRecognizer.cpp �������� ���������� ������� ��� ��������, �������� �� ������� �����������
// 30.03.2022

#include "TautologyRecognizer.h"


void negateLiterals(string&);
void replaceImplications(string&);
void replaceEquivalences(string&);
void removeDoubleNegation(string&);
void replaceConjunctionWithStar(string&);
void replaceDisjunctionWithPlus(string&);
void toDNF(string&);
void minimize(string&);

void deMorgan(string&, int, int);
void conjunctionWithFormulaBefore(string&, int, int);
void disjunctionWithFormulaAfter(string&, int, int);
void conjunctionWithFormulaAfter(string&, int, int);

int beginOfSubformula(string, int);
int endOfSubformula(string, int);

vector<string> splitIntoSummands(string);
vector<string> negateSummands(vector<string>);
vector<string> cartesianProduct(vector<string>, vector<string>);
vector<string> multiplyStrings(string, string);
int indexOfMaxNestingLevel(string);
void print(vector<string>);
void replaceSummandWithFalseIfItContainsFalse(vector<string>&);
void replaceSummandWithFalseIfItContainsOpposingVariables(vector<string>&);
void removeTrueFromComplexSummands(vector<string>&);
void addAllPossibleGlueings(vector<string>&);
void tryCreateSummandWithCombinationOfNegationsOfUnarySummands(vector<string>&);
void replaceEverythingWithTrueIfAtLeastOneOfSummandsIsTrue(vector<string>&);


bool TautologyRecognizer::isTautology(string line) {
    backup = string(line);
    startRecognition(*this);
    return backup.length() == 1 && backup.at(0) == '1';
}

void startRecognition(TautologyRecognizer& recognizer) {
    string* formula = &recognizer.backup;
    //removeDoubleNegation(*formula);
    //negateLiterals(*formula);
    replaceEquivalences(*formula);
    replaceImplications(*formula);
    removeDoubleNegation(*formula);
    negateLiterals(*formula);
    replaceConjunctionWithStar(*formula);
    replaceDisjunctionWithPlus(*formula);
    toDNF(*formula);
    minimize(*formula);
}

void negateLiterals(string& formula) {
    Formula negation = Formula::NEGATION;
    int negationLength = negation.length();
    int indexOfConnector = negation.indexOfConnector();
    int indexOfLiteral = negation.indexOfVar(0);
    for (int i = indexOfConnector; i < formula.length(); i++) {
        string subFormula = formula.substr(i - indexOfConnector, negationLength);
        if (negation.stringMatchPattern(subFormula)) {
            char literal = subFormula.at(indexOfLiteral);
            if (literal >= 'A' && literal <= 'Z') {
                literal = 'a' + (literal - 'A');
            }
            else if (literal >= 'a' && literal <= 'z') {
                literal = 'A' + (literal - 'a');
            }
            else {
                literal = '0' + !(literal - '0');
            }
            formula.erase(i - indexOfConnector, negationLength);
            formula.insert(i - indexOfConnector, 1, literal);
            i--;
        }
    }
}

void replaceImplications(string& formula) {
    int indexOfImplication = formula.find("->");
    while (indexOfImplication >= 0) {
        int startOfImplication = beginOfSubformula(formula, indexOfImplication);
        int endOfImplication = endOfSubformula(formula, indexOfImplication);
        string leftPart = formula.substr(startOfImplication + 1, indexOfImplication - startOfImplication - 1);
        string rightPart = formula.substr(indexOfImplication + 2, endOfImplication - indexOfImplication - 2);
        string insertion = "(!" + leftPart + ")\\/" + rightPart;
        formula.erase(startOfImplication + 1, endOfImplication - startOfImplication - 1);
        formula.insert(startOfImplication + 1, insertion);
        indexOfImplication = formula.find("->");
    }
}

void replaceEquivalences(string& formula) {
    int indexOfEquivalence = formula.find("~");
    while (indexOfEquivalence >= 0) {
        int startOfEquivalence = beginOfSubformula(formula, indexOfEquivalence);
        int endOfEquivalence = endOfSubformula(formula, indexOfEquivalence);
        string leftPart = formula.substr(startOfEquivalence + 1, indexOfEquivalence - startOfEquivalence - 1);
        string rightPart = formula.substr(indexOfEquivalence + 1, endOfEquivalence - indexOfEquivalence - 1);
        string insertion = "(" + leftPart + "->" + rightPart + ")/\\(" + rightPart + "->" + leftPart + ")";
        formula.erase(startOfEquivalence + 1, endOfEquivalence - startOfEquivalence - 1);
        formula.insert(startOfEquivalence + 1, insertion);
        indexOfEquivalence = formula.find("~");
    }
}


void removeDoubleNegation(string& formula) {
    int indexOfDoubleNegation = formula.find("!(!");
    while (indexOfDoubleNegation >= 0) {
        int endOfDoubleNegation = endOfSubformula(formula, indexOfDoubleNegation + 4);
        formula.erase(endOfDoubleNegation, 2);
        formula.erase(indexOfDoubleNegation - 1, 4);
        indexOfDoubleNegation = formula.find("!(!");
    }
}


void replaceConjunctionWithStar(string& formula) {
    replace(formula, "/\\", "*");
}

void replaceDisjunctionWithPlus(string& formula) {
    replace(formula, "\\/", "+");
}

void toDNF(string& formula) {
    bool possibleTransformationsLeft = true;
    Formula negation = Formula::NEGATION;
    while (possibleTransformationsLeft) {
        possibleTransformationsLeft = false;
        int indexOfMaxNest = indexOfMaxNestingLevel(formula);
        int endOfMaxNest = endOfSubformula(formula, indexOfMaxNest + 1);
        if (indexOfMaxNest >= negation.indexOfConnector() && formula.at(indexOfMaxNest - 1) == negation.charAt(negation.indexOfConnector())) {
            deMorgan(formula, indexOfMaxNest, endOfMaxNest);
            possibleTransformationsLeft = true;
            continue;
        }
        if (indexOfMaxNest - 1 >= 0) {
            char charBeforeNesting = formula.at(indexOfMaxNest - 1);
            if (charBeforeNesting == '+') {//remove braces around nesting
                formula.erase(endOfMaxNest, 1);
                formula.erase(indexOfMaxNest, 1);
                possibleTransformationsLeft = true;
                continue;
            }
            else if (charBeforeNesting == '*') {// multiply summands with literal before nesting
                conjunctionWithFormulaBefore(formula, indexOfMaxNest, endOfMaxNest);
                possibleTransformationsLeft = true;
            }
            else {
                char charAfterNesting = formula.at(endOfMaxNest + 1);
                if (charAfterNesting == '+') {// remove braces around nesting and maybe around right part
                    disjunctionWithFormulaAfter(formula, indexOfMaxNest, endOfMaxNest);
                    possibleTransformationsLeft = true;
                }
                else {// summands in nesting mix with (literal | summands after nesting)
                    conjunctionWithFormulaAfter(formula, indexOfMaxNest, endOfMaxNest);
                    possibleTransformationsLeft = true;
                }
            }
        }
    }
}

void deMorgan(string& formula, int begin, int end) {
    string subFormula = formula.substr(begin + 1, end - begin - 1);
    int lenToErase = subFormula.length() + 2;// 2 is for braces
    replace(subFormula, "*", "");
    vector<string> summands = splitIntoSummands(subFormula);
    vector<string> negatedSummands = negateSummands(summands);
    string prefix = negatedSummands.size() > 1 ? "(" : "";
    string postfix = negatedSummands.size() > 1 ? ")" : "";
    string joined = join(negatedSummands, ")*(", prefix, postfix);
    formula.erase(begin - 1, lenToErase + 1);// 1 is for ! in both cases(in next line 1 is for !)
    formula.insert(begin - 1, joined);
}


void conjunctionWithFormulaBefore(string& formula, int begin, int end) {
    int indexOfBeginOfLiteralSequence = beginOfSubformula(formula, begin - 2);
    string literalSequence = formula.substr(indexOfBeginOfLiteralSequence + 1, begin - indexOfBeginOfLiteralSequence - 2);
    string subFormula = formula.substr(begin + 1, end - begin - 1);
    vector<string> product = multiplyStrings(literalSequence, subFormula);
    leaveUniqueLettersInElements(product);
    leaveUnique(product);
    bool bracesAreNeeded = product.size() > 1 && ((indexOfBeginOfLiteralSequence - 1 >= 0 && formula.at(indexOfBeginOfLiteralSequence - 1) != '(') || (end + 1 < formula.length() && formula.at(end + 1) != ')'));
    string prefix = bracesAreNeeded ? "(" : "";
    string postfix = bracesAreNeeded ? ")" : "";
    string replacement = join(product, "+", prefix, postfix);
    formula.erase(indexOfBeginOfLiteralSequence + 1, end - indexOfBeginOfLiteralSequence);
    formula.insert(indexOfBeginOfLiteralSequence + 1, replacement);
}

void disjunctionWithFormulaAfter(string& formula, int begin, int end) {
    int indexOfBeginOfSummandsAfterNesting = end + 2;
    char charAfterPlus = formula.at(indexOfBeginOfSummandsAfterNesting);
    if (charAfterPlus == '(') {// remove braces around right part
        int indexOfEndOfSummandsAfterNesting = endOfSubformula(formula, indexOfBeginOfSummandsAfterNesting + 1);
        string rightPart = formula.substr(indexOfBeginOfSummandsAfterNesting + 1, indexOfEndOfSummandsAfterNesting - indexOfBeginOfSummandsAfterNesting - 1);
        replace(rightPart, "*", "");
        formula.erase(indexOfEndOfSummandsAfterNesting, 1);
        formula.erase(indexOfBeginOfSummandsAfterNesting + 1, indexOfEndOfSummandsAfterNesting - indexOfBeginOfSummandsAfterNesting - 1);
        formula.insert(indexOfBeginOfSummandsAfterNesting + 1, rightPart);
        formula.erase(indexOfBeginOfSummandsAfterNesting, 1);
    }
    formula.erase(end, 1);
    formula.erase(begin, 1);
}

void conjunctionWithFormulaAfter(string& formula, int begin, int end) {
    int indexOfBeginOfSummandsAfterNesting = end + 2;
    char charAfterPlus = formula.at(indexOfBeginOfSummandsAfterNesting);
    if (charAfterPlus == '(') {
        indexOfBeginOfSummandsAfterNesting++;
    }
    int indexOfEndOfSummandsAfterNesting = endOfSubformula(formula, indexOfBeginOfSummandsAfterNesting + 1);
    string rightPart = formula.substr(indexOfBeginOfSummandsAfterNesting, indexOfEndOfSummandsAfterNesting - indexOfBeginOfSummandsAfterNesting);
    string leftPart = formula.substr(begin + 1, end - begin - 1);
    vector<string> product = multiplyStrings(leftPart, rightPart);
    leaveUniqueLettersInElements(product);
    leaveUnique(product);
    bool bracesAreNeeded = product.size() > 1 && (formula.at(begin - 1) != '(' || (indexOfEndOfSummandsAfterNesting + 1 < formula.length() && formula.at(indexOfEndOfSummandsAfterNesting + 1) != ')'));
    string prefix = (bracesAreNeeded) ? "(" : "";
    string postfix = (bracesAreNeeded) ? ")" : "";
    string replacement = join(product, "+", prefix, postfix);
    formula.erase(begin, indexOfEndOfSummandsAfterNesting - begin + (indexOfBeginOfSummandsAfterNesting - end) - 2);
    formula.insert(begin, replacement);
}
void minimize(string& formula) {
    replace(formula, "*", "");
    if (formula.at(0) == '(') {
        formula.erase(formula.length() - 1, 1);
        formula.erase(0, 1);
    }
    vector<string> summands = splitIntoSummands(formula);
    leaveUniqueLettersInElements(summands);
    leaveUnique(summands);
    replaceSummandWithFalseIfItContainsOpposingVariables(summands);
    leaveUnique(summands);
    replaceSummandWithFalseIfItContainsFalse(summands);
    removeTrueFromComplexSummands(summands);
    addAllPossibleGlueings(summands);
    leaveUnique(summands);
    tryCreateSummandWithCombinationOfNegationsOfUnarySummands(summands);
    replaceEverythingWithTrueIfAtLeastOneOfSummandsIsTrue(summands);
    formula = join(summands, "+", "", "");
}

vector<string> splitIntoSummands(string formula) {
    vector<string> summands;
    while (formula.length() > 0) {
        int indexOfPlus = formula.find("+");
        if (indexOfPlus < 0) {
            indexOfPlus = formula.length();
        }
        summands.push_back(formula.substr(0, indexOfPlus));
        formula.erase(0, indexOfPlus + 1);
    }
    return summands;
}

vector<string> negateSummands(vector<string> summands) {
    vector<string> negated;
    for (int i = 0; i < summands.size(); i++) {
        string summand = summands[i];
        string negatedSummand;
        for (int indexInSummand = 0; indexInSummand < summand.length(); indexInSummand++) {
            string variable = summand.substr(indexInSummand, 1);
            negatedSummand.append("(!" + variable + ")");
            if (indexInSummand < summand.length() - 1) {
                negatedSummand.append("+");
            }
        }
        negateLiterals(negatedSummand);
        negated.push_back(negatedSummand);
    }
    return negated;
}

int indexOfMaxNestingLevel(string formula) {
    int indexOfMaxNesting = 0;
    int maxNesting = 0;
    int currentNesting = 0;
    for (int i = 0; i < formula.length(); i++) {
        char currentChar = formula.at(i);
        if (currentChar == '(') {
            currentNesting++;
            if (currentNesting > maxNesting) {
                maxNesting = currentNesting;
                indexOfMaxNesting = i;
            }
        }
        else if (currentChar == ')') {
            currentNesting--;
        }
    }
    return indexOfMaxNesting;
}

void print(vector<string> strings) {
    printf("%s\n", join(strings, ", ", "[", "]").c_str());
}

vector<string> multiplyStrings(string left, string right) {
    replace(left, "*", "");
    replace(right, "*", "");
    vector<string> leftSummand = splitIntoSummands(left);
    vector<string> rightSummands = splitIntoSummands(right);
    return cartesianProduct(leftSummand, rightSummands);
}

vector<string> cartesianProduct(vector<string> first, vector<string> second) {
    vector<string> product;
    for (int i = 0; i < second.size(); i++) {
        string fromSecond = second[i];
        for (int j = 0; j < first.size(); j++) {
            string fromFirst = first[j];
            fromFirst.append(fromSecond);
            product.push_back(fromFirst);
        }
    }
    return product;
}

void replaceSummandWithFalseIfItContainsOpposingVariables(vector<string>& strings) {
    for (int wordIndex = 0; wordIndex < strings.size(); wordIndex++) {
        string word = strings[wordIndex];
        for (int letterIndex = 0; letterIndex < word.size(); letterIndex++) {
            char variable = word.at(letterIndex);
            char target = ' ';
            if (variable >= 'a' && variable <= 'z') {
                target = 'A' + (variable - 'a');
            }
            else if (variable >= 'A' && variable <= 'Z') {
                target = 'a' + (variable - 'A');
            }
            else {
                continue;
            }
            int indexOftarget = word.find(target);
            if (indexOftarget >= 0) {
                strings[wordIndex] = "0";
                letterIndex = word.size();
            }
        }
    }
}

void replaceSummandWithFalseIfItContainsFalse(vector<string>& strings) {
    for (int wordIndex = 0; wordIndex < strings.size(); wordIndex++) {
        string word = strings[wordIndex];
        int indexOfFalse = word.find("0");
        if (indexOfFalse >= 0) {
            strings[wordIndex] = "0";
        }
    }
}

void removeTrueFromComplexSummands(vector<string>& strings) {
    for (int wordIndex = 0; wordIndex < strings.size(); wordIndex++) {
        string word = strings[wordIndex];
        int indexOfTrue = 0;
        while ((indexOfTrue = word.find("1")) >= 0 && word.length() > 1) {
            word.erase(indexOfTrue, 1);
        }
        strings[wordIndex] = word;
    }
}

void addAllPossibleGlueings(vector<string>& strings) {
    for (int firstWordIndex = 0; firstWordIndex < strings.size(); firstWordIndex++) {
        string firstWord = strings[firstWordIndex];
        for (int secondWordIndex = 0; secondWordIndex < strings.size(); secondWordIndex++) {
            string secondWord = strings[secondWordIndex];
            if (firstWord.length() == 1) {
                continue;
            }
            for (int firstLetterIndex = 0; firstLetterIndex < firstWord.size(); firstLetterIndex++) {
                char variable = firstWord.at(firstLetterIndex);
                char target = ' ';
                if (variable >= 'a' && variable <= 'z') {
                    target = 'A' + (variable - 'a');
                }
                else if (variable >= 'A' && variable <= 'Z') {
                    target = 'a' + (variable - 'A');
                }
                else {
                    continue;
                }
                int indexOfTarget = secondWord.find(target);
                if (indexOfTarget >= 0) {
                    string test1 = firstWord;
                    string test2 = secondWord;
                    test1.erase(firstLetterIndex, 1);
                    test2.erase(indexOfTarget, 1);
                    int startPos = 0;
                    startPos = test1.find(test2);
                    if (startPos >= 0) {
                        strings.push_back(test1);
                        firstLetterIndex = firstWord.size();
                        break;
                    }
                }
            }
        }
    }
}

void tryCreateSummandWithCombinationOfNegationsOfUnarySummands(vector<string>& strings) {
    string composition = "";
    vector<string> unary;
    for (int i = 0; i < strings.size(); i++) {
        if (strings[i].length() == 1) {
            char variable = strings[i].at(0);
            char negation = ' ';
            if (variable >= 'a' && variable <= 'z') {
                negation = 'A' + (variable - 'a');
            }
            else if (variable >= 'A' && variable <= 'Z') {
                negation = 'a' + (variable - 'A');
            }
            else {
                continue;
            }
            composition.append(1, negation);
            unary.push_back(string(negation, 1));
        }
    }
    sort(composition);
    for (int wordIndex = 0; wordIndex < strings.size(); wordIndex++) {
        string word = strings[wordIndex];
        bool canBeCreated = word.length() > 0;
        for (int letterIndex = 0; letterIndex < word.length() && canBeCreated; letterIndex++) {
            int indexInComposition = composition.find(word.at(letterIndex));
            if (indexInComposition < 0) {
                canBeCreated = false;
            }
        }
        if (canBeCreated) {
            strings.erase(strings.begin(), strings.end());
            strings.push_back("1");
            return;
        }
    }
}

void replaceEverythingWithTrueIfAtLeastOneOfSummandsIsTrue(vector<string>& strings) {
    for (int i = 0; i < strings.size(); i++) {
        if (strings[i] == "1") {
            strings.erase(strings.begin(), strings.end());
            strings.push_back("1");
        }
    }

}

int beginOfSubformula(string formula, int index) {
    int start = index;
    int leftNesting = 0;
    for (; start >= 0 && leftNesting >= 0; start--) {
        char currentChar = formula.at(start);
        if (currentChar == '(') {
            leftNesting--;
        }
        else if (currentChar == ')') {
            leftNesting++;
        }
    }
    start++;
    return start;
}

int endOfSubformula(string formula, int index) {
    int end = index;
    int rightNesting = 0;
    for (; end < formula.length() && rightNesting >= 0; end++) {
        char currentChar = formula.at(end);
        if (currentChar == ')') {
            rightNesting--;
        }
        else if (currentChar == '(') {
            rightNesting++;
        }
    }
    end--;
    return end;
}