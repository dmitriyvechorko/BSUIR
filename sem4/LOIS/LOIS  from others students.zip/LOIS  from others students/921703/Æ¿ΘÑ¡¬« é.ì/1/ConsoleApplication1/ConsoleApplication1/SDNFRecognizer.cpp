
////////////////////////////////////////////////////////////////////////////////////
// ������������ ������ �1 �� ���������� ���������� ������ ���������������� ������
// ��������� ��������� ������ 921703 ����� ������� �������� ������������
// ���� SDNFRecognizer.cpp �������� ���������� �������, ������������ �������� �� ������ ����
// 22.02.2022
// 10.03.2022 ��������� ������������� ������ Formula

#include "SDNFRecognizer.h"

bool containsEqualRows(vector<char*>);
bool allRowsContainSameVariables(vector<char*>);
void sortCharArraysVector(vector<char*>&);

bool SDNFRecognizer::isSDNF(string line) {
    bool isSdnf = false;
    fullTruthTable.clear();

    try {
    backUp = string(line);
        for (size_t i = 0; i < backUp.size(); i++) {
            int pos = LEGAL_CHARACTERS.find(backUp.at(i));
            if (pos < 0) {
                return false;
            }
        }
        if (!checkIfBracesAreBalanced(backUp)) {
            return false;
        }
        startRecognition(*this);
        Formula literal = Formula::LITERAL;
        if (!containsEqualRows(fullTruthTable) && allRowsContainSameVariables(fullTruthTable) && literal.stringMatchPattern(backUp)) {
            isSdnf = true;
        }


    }
    catch (const std::runtime_error& e) {
        printf("message = %s\n", e.what());
    }
    printTable();
    return isSdnf;
}


void startRecognition(SDNFRecognizer& recognizer) {
    int previousDisjunction = 0;
    string disjunctionConnector = "\\/";
    int nextDisjunction = recognizer.backUp.find(disjunctionConnector);
    if (nextDisjunction < 0) {
        nextDisjunction = recognizer.backUp.length() - 1;
    }
    while (previousDisjunction < nextDisjunction) {
        recognizer.fullTruthTable.push_back(zeros('Z' - 'A' + 1));
        removeNegationsInSummand(recognizer, previousDisjunction, nextDisjunction);
        removeConjunctionsInSummand(recognizer, previousDisjunction, nextDisjunction);
        previousDisjunction = nextDisjunction + 2;
        nextDisjunction = recognizer.backUp.find(disjunctionConnector, nextDisjunction + 1);
        if (nextDisjunction < 0) {
            nextDisjunction = recognizer.backUp.length();
        }
    }
    removeRemainingDisjunctions(recognizer, 0, recognizer.backUp.length());
}

void removeNegationsInSummand(SDNFRecognizer& recognizer, int& beginOfSummand, int& endOfSummand) {
    Formula negation = Formula::NEGATION;
    for (size_t i = beginOfSummand; i < endOfSummand; i++) {
        int forwardShift = i + negation.indexOfConnector();
        if (forwardShift < recognizer.backUp.size() && negation.stringMatchPattern(recognizer.backUp.substr(i, negation.length()))) {
            subformulaStartsAt(recognizer, negation, i, true, false);
            endOfSummand -= (negation.length()-1);
            i--;
        }
    }
}

void removeConjunctionsInSummand(SDNFRecognizer& recognizer, int& beginOfSummand, int& endOfSummand) {
    Formula conjunction = Formula::CONJUNCTION;
    int indexOfConnector = conjunction.indexOfConnector();
    int removedConjunctions = 0;
    bool possibleConjunctionIsInSummand = true;
    while (possibleConjunctionIsInSummand) {
        possibleConjunctionIsInSummand = false;
        for (size_t i = beginOfSummand; i < endOfSummand; i++) {
            int shift = i - indexOfConnector;
            int remaining = i + (conjunction.length() - indexOfConnector - 1);
            if (shift >= 0 && remaining < recognizer.backUp.size() && conjunction.stringMatchPattern(recognizer.backUp.substr(shift, conjunction.length()))) {
                subformulaStartsAt(recognizer, conjunction, shift, false, true);
                i = shift;
                endOfSummand -= (conjunction.length() - 1);
                removedConjunctions++;
                possibleConjunctionIsInSummand = true;
            }
        }
    }
    if (removedConjunctions == 0) {
        Formula literal = Formula::LITERAL;
        for (size_t i = beginOfSummand; i < endOfSummand; i++) {
            printf("begin = %d, end = %d, [begin] = %c, [begin + 1] = %c\n", beginOfSummand, endOfSummand, recognizer.backUp.at(beginOfSummand), recognizer.backUp.at(beginOfSummand + 1));
            if (recognizer.backUp.at(i) >= 'A' && recognizer.backUp.at(i) <= 'Z') {
                subformulaStartsAt(recognizer, literal, i, false, true);
            }
        }
    }
}

void removeRemainingDisjunctions(SDNFRecognizer& recognizer, int beginOfSummand, int endOfSummand) {
    Formula disjunction = Formula::DISJUNCTION;
    int indexOfConnector = disjunction.indexOfConnector();
    bool possibleDisjunctionIsInSummand = true;
    while (possibleDisjunctionIsInSummand) {
        possibleDisjunctionIsInSummand = false;
        for (size_t i = beginOfSummand; i < endOfSummand; i++) {
            int shift = i - indexOfConnector;
            int remaining = i + (disjunction.length() - indexOfConnector - 1);
            if (shift >= 0 && remaining < recognizer.backUp.size() && disjunction.stringMatchPattern(recognizer.backUp.substr(shift, disjunction.length()))) {// stopped here
                subformulaStartsAt(recognizer, disjunction, shift, false, false);
                i = shift;
                endOfSummand -= (disjunction.length()-1);
                possibleDisjunctionIsInSummand = true;
            }
        }
    }
}

void subformulaStartsAt(SDNFRecognizer& recognizer, Formula formula, int startsAt, bool addNegations, bool addStatements) {
    int expectedSubstringLength = formula.length();
    int amountOfVariables = formula.amountOfVars();
    string substring = recognizer.backUp.substr(startsAt, expectedSubstringLength);
    if (addNegations) {
        for (size_t i = 0; i < amountOfVariables; i++) {
            char variable = substring.at(formula.indexOfVar(i));
            if (variable != '?') {
                recognizer.addNegation(variable);
            }
        }
    }
    if (addStatements) {
        for (size_t i = 0; i < amountOfVariables; i++) {
            char variable = substring.at(formula.indexOfVar(i));
            if (variable != '?') {
                recognizer.addStatement(variable);
            }
        }
    }
    recognizer.backUp.erase(startsAt, expectedSubstringLength);
    recognizer.backUp.insert(startsAt, "?");
}

bool containsEqualRows(vector<char*> truthTable) {
    if (truthTable.size() < 2) {
        return false;
    }
    vector<char*> sorted = truthTable;
    sortCharArraysVector(sorted);
    for (size_t i = 0; i < sorted.size() - 1; i++) {
        if (strcmp(sorted.at(i), sorted.at(i + 1)) == 0) {
            return true;
        }
    }
    return false;
}
void sortCharArraysVector(vector<char*>& table) {
    for (size_t i = 0; i < table.size(); i++) {
        for (size_t j = i; j < table.size(); j++) {
            if (strcmp(table.at(i), table.at(j))>0) {
                char* temp = table.at(i);
                table.at(i) = table.at(j);
                table.at(j) = temp;
            }
        }
    }

}

bool allRowsContainSameVariables(vector<char*> truthTable) {
    if (truthTable.size() < 2) {
        return true;
    }
    int rowLength = strlen(truthTable.at(truthTable.size() - 1));
    vector<char*> mask;
    for (size_t i = 0; i < truthTable.size(); i++) {
        char* maskRow = zeros(rowLength);
        const char* truthTableRow = truthTable.at(i);
        for (size_t j = 0; j < rowLength; j++) {
            maskRow[j] = (truthTableRow[j] != '0') + '0';
        }
        mask.push_back(maskRow);
    }
    sortCharArraysVector(mask);
    return (strcmp(mask.at(0), mask.at(mask.size() - 1)) == 0);
}