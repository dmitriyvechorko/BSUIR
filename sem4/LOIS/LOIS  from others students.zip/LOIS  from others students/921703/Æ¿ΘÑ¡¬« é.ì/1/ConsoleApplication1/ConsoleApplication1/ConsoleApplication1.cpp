﻿
////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студентом группы 921703 БГУИР Тищенко Виталием Николаевичем
// Файл ConsoleApplication1.cpp содержит методы для взаимодействия с пользователем
// 22.02.2022
// 10.03.2022 шаблоны строк, которые вводит пользователь, заменены на переменные

#include <iostream>
#include <string>
#include <algorithm>
#include <vector>

#include "SDNFRecognizer.h"
#include "FormulaRecognizer.h"

using namespace std;
void startSdnfChecker();
void startUserTest();

const char* optionToStartSdnfChecker = "1";
const char* optionToStartUserTest = "2";
const char* optionToExit = "exit";

int main() {
    string line = "";
    while (strcmp(line.c_str(), optionToExit) != 0) {
        printf("Enter %s to check whether input is SDNF;\nEnter %s to test yourself;\nTo exit print %s.\n", optionToStartSdnfChecker, optionToStartUserTest, optionToExit);
        getline(cin, line);
        if (strcmp(line.c_str(), optionToExit) == 0) {
            printf("Exit requested....");
            continue;
        }
        if (line == "") {
            continue;
        }
        if (strcmp(line.c_str(), optionToStartSdnfChecker) == 0) {
            startSdnfChecker();
        }
        else if (strcmp(line.c_str(), optionToStartUserTest) == 0) {
            startUserTest();
        }
    }
    return 0;

}



void startSdnfChecker() {
    string line = "";
    FormulaRecognizer formulaRecognizer = FormulaRecognizer();
    SDNFRecognizer sdnfRecognizer = SDNFRecognizer();

    while (strcmp(line.c_str(), optionToExit) != 0) {
        printf("Enter line of text! To exit print exit.\n");
        getline(cin, line);
        if (strcmp(line.c_str(), optionToExit) == 0) {
            printf("Exit requested....");
            continue;
        }
        if (line == "") {
            continue;
        }

        if (formulaRecognizer.isFormula(line)) {
            printf("%s is formula\n", line.c_str());
            if (sdnfRecognizer.isSDNF(line)) {
                printf("%s is SDNF\n", line.c_str());
            }
            else {
                printf("%s is not SDNF\n", line.c_str());
            }
        }
        else {
            printf("%s is not formula\n", line.c_str());
        }
    }
}

void startUserTest() {
    vector<const char*> questions;
    int amountOfRightAnswers = 0;
    SDNFRecognizer sdnfRecognizer = SDNFRecognizer();

    questions.push_back("((A/\\B)\\/((!A)/\\B))");
    questions.push_back("(((!C)/\\(D/\\P))\\/((!K)/\\((!D)/\\P)))");
    questions.push_back("(((!G)/\\(X/\\Q))\\/((!G)/\\((!X)/\\Q)))");
    questions.push_back("(U/\\(!U))");
    questions.push_back("(Y\\/(!Y))");
    questions.push_back("W");
    questions.push_back("(O->T)");
    questions.push_back("(I~P)");
    questions.push_back("(!T)");
    questions.push_back("!(E)");
    questions.push_back("((J\\/Z)/\\((!J)\\/Z))");
    questions.push_back("((S\\/M)\\/((!S)\\/M))");

    random_shuffle(questions.begin(), questions.end());

    const char* positiveAnswer = "yes";
    const char* negativeAnswer = "no";

    for (size_t i = 0; i < questions.size(); i++) {
        string userAnswer;
        while (strcmp(userAnswer.c_str(),positiveAnswer) != 0 && strcmp(userAnswer.c_str(), negativeAnswer) != 0) {
            system("cls");
            printf("Is it SDNF(%s or %s)?\n%s\n", positiveAnswer, negativeAnswer, questions.at(i));
            getline(cin, userAnswer);
        }
        bool rightAnswer = sdnfRecognizer.isSDNF(string(questions.at(i)));
        if (rightAnswer && strcmp(userAnswer.c_str(), positiveAnswer) == 0) {
            amountOfRightAnswers++;
        }
        else if (!rightAnswer && strcmp(userAnswer.c_str(), negativeAnswer) == 0) {
            amountOfRightAnswers++;
        }
    }
    system("cls");
    printf("Your score is %d/%d. Great work!\n", amountOfRightAnswers, questions.size());
}