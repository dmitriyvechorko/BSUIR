package org.example.gui;

import org.example.exceptions.InvalidAtomicExpressionSyntaxException;
import org.example.exceptions.InvalidBracketsException;
import org.example.exceptions.InvalidOperatorException;
import org.example.exceptions.InvalidSyntaxCharacterException;
import org.example.parser.Constants;
import org.example.parser.LEParser;
import org.example.tree.LETree;
import org.example.util.SknfUtil;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;

////////////////////////////////////////////
//Лабораторная работа №2 по дисциплине ЛОИС
//Выполнена студентом группы 921703
//Торопом Никитой Сергеевичем
//Использованные источники:
//1 - docs.oracle.com
//2 - javatpoint.com

public class MainWindow extends JFrame {

    public static final String GUI_CONJUNCTION = "/\\";
    public static final String GUI_DISJUNCTION = "\\/";
    public static final String GUI_NEGATION = "!";
    public static final String GUI_EQUALITY = "~";
    public static final String GUI_IMPLICATION = "->";
    private final JTextField expressionField = new JTextField();
    private final JPanel mainPanel = new JPanel(new BorderLayout());
    private final JPanel instrumentationPanel = new JPanel(new GridLayout(1, 1));

    private final JPanel buttonsPanel = new JPanel(new GridLayout(6, 1));
    private final JButton conjunctionButton = new JButton("∧");
    private final JButton disjunctionButton = new JButton("∨");
    private final JButton negationButton = new JButton("¬");
    private final JButton equalityButton = new JButton("~");
    private final JButton implicationButton = new JButton("→");
    private final JButton createPcnfButton = new JButton("Create");
    private final Font mainFont;

    private int offset = 0;


    public MainWindow() throws HeadlessException {
        mainFont = new Font("SansSerif", Font.BOLD, 20);
        expressionField.setFont(mainFont);
        addButtons();
        instrumentationPanel.add(buttonsPanel, 0);
        mainPanel.add(expressionField, BorderLayout.NORTH);
        mainPanel.add(instrumentationPanel, BorderLayout.CENTER);

        this.add(mainPanel);
    }

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        MainWindow window = new MainWindow();

        window.setBounds(400, 400, 900, 400);
        window.setVisible(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void addButtons() {
        conjunctionButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_CONJUNCTION);
            offset = 2;
        });
        conjunctionButton.setFont(mainFont);
        disjunctionButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_DISJUNCTION);
            offset = 2;
        });
        disjunctionButton.setFont(mainFont);

        negationButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_NEGATION);
            offset = 1;
        });
        negationButton.setFont(mainFont);

        equalityButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_EQUALITY);
            offset = 1;
        });
        equalityButton.setFont(mainFont);

        implicationButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_IMPLICATION);
            offset = 2;
        });
        implicationButton.setFont(mainFont);

        createPcnfButton.addActionListener(e -> {
            try {
                JOptionPane.showMessageDialog(this, replaceOperatorsToGui(
                        SknfUtil.createPcnf(LEParser.valueOf(replaceOperatorsToEngine(expressionField.getText())))));
            } catch (InvalidOperatorException | InvalidSyntaxCharacterException | InvalidAtomicExpressionSyntaxException | InvalidBracketsException ex) {
            }
        });
        createPcnfButton.setEnabled(true);
        createPcnfButton.setFont(mainFont);

        buttonsPanel.add(conjunctionButton);
        buttonsPanel.add(disjunctionButton);
        buttonsPanel.add(negationButton);
        buttonsPanel.add(equalityButton);
        buttonsPanel.add(implicationButton);
        buttonsPanel.add(createPcnfButton);
    }

    private void setSymbolToCurrentPosition(String symbol) {
        StringBuilder text = new StringBuilder(expressionField.getText());
        int startPosition = expressionField.getCaretPosition();
        text.insert(startPosition, symbol);
        expressionField.setText(text.toString());
        expressionField.setCaretPosition(startPosition + offset);
    }

    private String replaceOperatorsToEngine(String expression) {
        return expression.replace(MainWindow.GUI_CONJUNCTION, String.valueOf(Constants.CONJUNCTION))
                .replace(MainWindow.GUI_DISJUNCTION, String.valueOf(Constants.DISJUNCTION))
                .replace(MainWindow.GUI_IMPLICATION, String.valueOf(Constants.IMPLICIT));
    }

    private String replaceOperatorsToGui(String expression) {
        return expression.replace(String.valueOf(Constants.CONJUNCTION), MainWindow.GUI_CONJUNCTION)
                .replace(String.valueOf(Constants.DISJUNCTION), MainWindow.GUI_DISJUNCTION)
                .replace(String.valueOf(Constants.IMPLICIT), MainWindow.GUI_IMPLICATION);
    }
}
