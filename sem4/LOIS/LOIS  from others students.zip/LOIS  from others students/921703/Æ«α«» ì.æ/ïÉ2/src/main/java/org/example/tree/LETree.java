package org.example.tree;

////////////////////////////////////////////
//Лабораторная работа №2 по дисциплине ЛОИС
//Выполнена студентом группы 921703
//Торопом Никитой Сергеевичем
//Использованные источники:
//1 - docs.oracle.com
//2 - javatpoint.com
public class LETree {
    private final LENode root;

    public LETree(LENode root) {
        this.root = root;
    }

    public LENode getRoot() {
        return root;
    }

}
