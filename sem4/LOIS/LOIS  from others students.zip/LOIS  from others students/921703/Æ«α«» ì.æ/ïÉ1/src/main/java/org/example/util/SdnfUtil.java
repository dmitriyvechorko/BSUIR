package org.example.util;

import org.example.parser.Constants;
import org.example.tree.Node;
import org.example.tree.Tree;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

////////////////////////////////////////////
//Лабораторная работа №1 по дисциплине ЛОИС
//Выполнено студентом группы 921703
//Торопом Никитой Сергеевичем
//Вариант d - проверка правильности СДНФ
//Использованные источники:
//1 - docs.oracle.com
//2 - javatpoint.com
public class SdnfUtil {
    private SdnfUtil() {
    }

    public static boolean isSdnf(Tree expression) {
        boolean isSyntaxValid = isSdnfSyntaxValid(expression.getRoot().getExpression());
        if (!isSyntaxValid)
            return false;
        List<Node> disjunctionParts = getDisjunctionParts(expression.getRoot());
        List<Node> leaves = new ArrayList<>();
        getExpressionLists(expression.getRoot(), leaves);
        leaves = leaves.stream().distinct().toList();
        for (Node part : disjunctionParts) {
            List<Node> partLeaves = new ArrayList<>();
            getExpressionLists(part, partLeaves);
            if (leaves.size() != partLeaves.size())
                return false;
        }
        List<List<Node>> conjunctionParts = new ArrayList<>();
        for (int i = 0; i < disjunctionParts.size(); i++) {
            List<Node> currentConjunctionPart = getConjunctionParts(disjunctionParts.get(i));
            for (Node node : currentConjunctionPart) {
                boolean isFlat = checkIsConjunctionFlat(node);
                if (!isFlat)
                    return false;
            }

            conjunctionParts.add(currentConjunctionPart);
        }
        return checkConjunctionDuplicates(conjunctionParts);
    }

    private static boolean checkIsConjunctionFlat(Node node) {
        if (node.getLeftChild() == null) {
            if (node.getRightChild() == null) {
                return true;
            } else {
                return checkIsConjunctionFlat(node.getRightChild());
            }
        }
        if (node.getLeftChild().getOperatorSymbol() == Constants.NEGATION
                && node.getLeftChild().getRightChild().getOperatorSymbol() != '\u0000')
            return true;
        if (node.getRightChild().getOperatorSymbol() == Constants.NEGATION
                && node.getRightChild().getRightChild().getOperatorSymbol() != '\u0000')
            return true;
        return false;
    }

    private static boolean checkConjunctionDuplicates(List<List<Node>> conjunctions) {
        var uniqConjunctions = conjunctions
                .stream()
                .map(e -> e.stream()
                        .map(node -> String.valueOf(node.getExpression()))
                        .sorted()
                        .reduce((a, b) -> a + b))
                .filter(Optional::isPresent)
                .distinct()
                .toList();
        return uniqConjunctions.size() == conjunctions.size();
    }

    private static List<Node> getConjunctionParts(Node expression) {
        List<Node> result = new ArrayList<>();
        recAddLeavesForThisOperatorToList(result, expression, Constants.CONJUNCTION);
        return result;
    }

    private static List<Node> getDisjunctionParts(Node expression) {
        List<Node> result = new ArrayList<>();
        recAddLeavesForThisOperatorToList(result, expression, Constants.DISJUNCTION);
        return result;
    }

    private static void recAddLeavesForThisOperatorToList(List<Node> nodes, Node currentNode, Character operator) {
        if (currentNode.getOperatorSymbol() != operator) {
            nodes.add(currentNode);
            return;
        }
        if (currentNode.getLeftChild() != null) {
            if (currentNode.getLeftChild().getOperatorSymbol() == operator) {
                recAddLeavesForThisOperatorToList(nodes, currentNode.getLeftChild(), operator);
                return;
            } else {
                nodes.add(currentNode.getLeftChild());
            }
        }
        if (currentNode.getRightChild() != null) {
            if (currentNode.getRightChild().getOperatorSymbol() == operator) {
                recAddLeavesForThisOperatorToList(nodes, currentNode.getRightChild(), operator);
            } else {
                nodes.add(currentNode.getRightChild());
            }
        }
    }

    private static void getExpressionLists(Node node, Collection<Node> leaves) {
        if (node.getLeftChild() == null
                && node.getRightChild() == null
                && !node.getExpression().isEmpty()
                && node.getExpression().charAt(0) != Constants.TRUE
                && node.getExpression().charAt(0) != Constants.FALSE)
            leaves.add(node);

        if (node.getLeftChild() != null)
            getExpressionLists(node.getLeftChild(), leaves);
        if (node.getRightChild() != null)
            getExpressionLists(node.getRightChild(), leaves);
    }

    private static String disjunctionBracketsEncapsulation(Map<String, Boolean> values) {
        StringBuilder result = new StringBuilder("(");
        values.forEach((k, v) -> {
            result.append(getAtomicPart(k, v)).append(Constants.DISJUNCTION).append('(');
        });
        result.delete(result.length() - 2, result.length());
        if (result.charAt(result.length() - 2) == '(')
            result.delete(result.length() - 2, result.length() - 1);
        else
            result.delete(result.length() - 4, result.length() - 3);
        result.append(")".repeat(Math.max(0, values.size() - 1)));
        return result.toString();

    }

    private static String getAtomicPart(String expression, Boolean value) {
        if (!value)
            return expression;
        else
            return "(" + Constants.NEGATION + expression + ")";
    }

    private static boolean isSdnfSyntaxValid(String expression) {
        boolean result;
        boolean res;
        if (expression.contains(String.valueOf(Constants.TRUE))) {
            res = true;
        } else if (expression.contains(String.valueOf(Constants.FALSE))) {
            res = true;
        } else {
            res = false;
        }
        if (!res) {
            result = true;
        } else
            result = false;
        return result;
    }

}
