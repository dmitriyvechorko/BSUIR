package org.example.tree;

import java.util.Map;
import java.util.Objects;
import java.util.function.BiPredicate;

////////////////////////////////////////////
//Лабораторная работа №1 по дисциплине ЛОИС
//Выполнено студентом группы 921703
//Торопом Никитой Сергеевичем
//Вариант d - проверка правильности СДНФ
//Использованные источники:
//1 - docs.oracle.com
//2 - javatpoint.com
public class Node {
    private final String expression;
    private BiPredicate<Boolean, Boolean> operator;
    private char operatorSymbol;
    private Node leftChild;
    private Node rightChild;

    public Node(String expression) {
        this.expression = expression;
    }

    public Node getLeftChild() {
        return leftChild;
    }

    public void setLeftChild(Node leftChild) {
        this.leftChild = leftChild;
    }

    public Node getRightChild() {
        return rightChild;
    }

    public void setRightChild(Node rightChild) {
        this.rightChild = rightChild;
    }

    public BiPredicate<Boolean, Boolean> getOperator() {
        return operator;
    }

    public char getOperatorSymbol() {
        return operatorSymbol;
    }

    public void setOperator(BiPredicate<Boolean, Boolean> operator, char operatorSymbol) {
        this.operator = operator;
        this.operatorSymbol = operatorSymbol;
    }

    public String getExpression() {
        return expression;
    }

    public boolean calcValue(Map<String, Boolean> parameters) {
        if (leftChild == null && rightChild == null) {
            return parameters.get(expression);
        } else if (leftChild == null) {
            return operator.test(null, rightChild.calcValue(parameters));
        } else {
            return operator.test(leftChild.calcValue(parameters), rightChild.calcValue(parameters));
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(expression);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Node node = (Node) o;
        return Objects.equals(expression, node.expression);
    }
}
