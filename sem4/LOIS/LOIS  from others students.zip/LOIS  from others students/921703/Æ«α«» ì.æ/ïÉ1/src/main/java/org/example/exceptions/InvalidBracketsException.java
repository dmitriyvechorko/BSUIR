package org.example.exceptions;

public class InvalidBracketsException extends Exception{
    public InvalidBracketsException() {
        super("Brackets are invalid");
    }
}
