package org.example.util;

import java.util.concurrent.atomic.AtomicInteger;

////////////////////////////////////////////
//Лабораторная работа №1 по дисциплине ЛОИС
//Выполнено студентом группы 921703
//Торопом Никитой Сергеевичем
//Вариант d - проверка правильности СДНФ
//Использованные источники:
//1 - docs.oracle.com
//2 - javatpoint.com
class StatesGenerator {
    private final AtomicInteger currentState = new AtomicInteger();

    public boolean[] getStates() {
        boolean[] booleans = new boolean[26];
        for (int i = 25; i >= 0; i--) {
            booleans[i] = ((currentState.get() & (1 << i)) != 0);
        }
        return booleans;
    }

    public boolean[] incrementAndGet() {
        currentState.incrementAndGet();
        return getStates();
    }

}
