package org.example.gui;

import org.example.exceptions.InvalidAtomicExpressionSyntaxException;
import org.example.exceptions.InvalidBracketsException;
import org.example.exceptions.InvalidOperatorException;
import org.example.exceptions.InvalidSyntaxCharacterException;
import org.example.parser.Constants;
import org.example.parser.Parser;
import org.example.tree.Tree;
import org.example.util.SdnfUtil;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;

////////////////////////////////////////////
//Лабораторная работа №1 по дисциплине ЛОИС
//Выполнено студентом группы 921703
//Торопом Никитой Сергеевичем
//Вариант d - проверка правильности СДНФ
//Использованные источники:
//1 - docs.oracle.com
//2 - javatpoint.com
public class MainWindow extends JFrame {

    public static final String GUI_CONJUNCTION = "/\\";
    public static final String GUI_DISJUNCTION = "\\/";
    public static final String GUI_NEGATION = "!";
    public static final String GUI_EQUALITY = "~";
    public static final String GUI_IMPLICATION = "->";
    private final JTextField expressionField = new JTextField();
    private final JPanel mainPanel = new JPanel(new BorderLayout());
    private final JPanel instrumentationPanel = new JPanel(new GridLayout(5, 1));

    private final JPanel buttonsPanel = new JPanel(new GridLayout(5, 1));
    private final JButton conjunctionButton = new JButton("/\\");
    private final JButton disjunctionButton = new JButton("\\/");
    private final JButton negationButton = new JButton("!");
    private final JButton equalityButton = new JButton("~");
    private final JButton implicationButton = new JButton("->");

    private final JPanel informationPanel = new JPanel(new GridLayout(1, 5));
    private final JLabel bracketsValidityLabel = new JLabel("Brackets: ");
    private final JLabel bracketsValidityStatusLabel = new JLabel("");
    private final JLabel syntaxValidityLabel = new JLabel("Syntax: ");
    private final JLabel syntaxValidityStatusLabel = new JLabel("");
    private final JLabel atomicSyntaxValidityLabel = new JLabel("Atomic: ");
    private final JLabel atomicSyntaxValidityStatusLabel = new JLabel("");
    private final JLabel operatorSyntaxValidityLabel = new JLabel("Operators: ");
    private final JLabel operatorSyntaxValidityStatusLabel = new JLabel("");
    private final JLabel sdnfValidityLabel = new JLabel("SDNF: ");
    private final JLabel sdnfValidityStatusLabel = new JLabel("");
    private final Font mainFont;

    private int offset = 0;


    public MainWindow() throws HeadlessException {
        mainFont = new Font("Comic Sans", Font.BOLD, 15);
        expressionField.setFont(mainFont);
        expressionField.getDocument().addDocumentListener(new ExpressionFieldListener());
        addButtons();
        addLabels();
        instrumentationPanel.add(informationPanel, 0);
        instrumentationPanel.add(buttonsPanel, 1);
        mainPanel.add(expressionField, BorderLayout.NORTH);
        mainPanel.add(instrumentationPanel, BorderLayout.CENTER);

        this.add(mainPanel);
    }

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        MainWindow window = new MainWindow();

        window.setBounds(400, 400, 900, 400);
        window.setVisible(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void addButtons() {
        conjunctionButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_CONJUNCTION);
            offset = 2;
        });
        conjunctionButton.setFont(mainFont);
        disjunctionButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_DISJUNCTION);
            offset = 2;
        });
        disjunctionButton.setFont(mainFont);

        negationButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_NEGATION);
            offset = 1;
        });
        negationButton.setFont(mainFont);

        equalityButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_EQUALITY);
            offset = 1;
        });
        equalityButton.setFont(mainFont);

        implicationButton.addActionListener(e -> {
            setSymbolToCurrentPosition(GUI_IMPLICATION);
            offset = 2;
        });
        implicationButton.setFont(mainFont);

        buttonsPanel.add(conjunctionButton);
        buttonsPanel.add(disjunctionButton);
        buttonsPanel.add(negationButton);
        buttonsPanel.add(equalityButton);
        buttonsPanel.add(implicationButton);
    }

    private void setSymbolToCurrentPosition(String symbol) {
        StringBuilder text = new StringBuilder(expressionField.getText());
        int startPosition = expressionField.getCaretPosition();
        text.insert(startPosition, symbol);
        expressionField.setText(text.toString());
        expressionField.setCaretPosition(startPosition + offset);
    }

    private void addLabels() {
        bracketsValidityLabel.setFont(mainFont);
        bracketsValidityStatusLabel.setFont(mainFont);
        syntaxValidityLabel.setFont(mainFont);
        syntaxValidityStatusLabel.setFont(mainFont);
        atomicSyntaxValidityLabel.setFont(mainFont);
        atomicSyntaxValidityStatusLabel.setFont(mainFont);
        operatorSyntaxValidityLabel.setFont(mainFont);
        operatorSyntaxValidityStatusLabel.setFont(mainFont);
        sdnfValidityLabel.setFont(mainFont);
        sdnfValidityStatusLabel.setFont(mainFont);

        informationPanel.add(bracketsValidityLabel);
        informationPanel.add(bracketsValidityStatusLabel);
        informationPanel.add(syntaxValidityLabel);
        informationPanel.add(syntaxValidityStatusLabel);
        informationPanel.add(atomicSyntaxValidityLabel);
        informationPanel.add(atomicSyntaxValidityStatusLabel);
        informationPanel.add(operatorSyntaxValidityLabel);
        informationPanel.add(operatorSyntaxValidityStatusLabel);
        informationPanel.add(sdnfValidityLabel);
        informationPanel.add(sdnfValidityStatusLabel);

    }

    private String replaceOperatorsToEngine(String expression) {
        return expression.replace(MainWindow.GUI_CONJUNCTION, String.valueOf(Constants.CONJUNCTION))
                .replace(MainWindow.GUI_DISJUNCTION, String.valueOf(Constants.DISJUNCTION))
                .replace(MainWindow.GUI_IMPLICATION, String.valueOf(Constants.IMPLICIT));
    }

    private String replaceOperatorsToGui(String expression) {
        return expression.replace(String.valueOf(Constants.CONJUNCTION), MainWindow.GUI_CONJUNCTION)
                .replace(String.valueOf(Constants.DISJUNCTION), MainWindow.GUI_DISJUNCTION)
                .replace(String.valueOf(Constants.IMPLICIT), MainWindow.GUI_IMPLICATION);
    }

    private class ExpressionFieldListener implements DocumentListener {
        @Override
        public void insertUpdate(DocumentEvent documentEvent) {
            checkExpression();
        }

        @Override
        public void removeUpdate(DocumentEvent documentEvent) {
            checkExpression();
        }

        @Override
        public void changedUpdate(DocumentEvent documentEvent) {
            checkExpression();
        }

        private void clearAllStatuses() {
            bracketsValidityStatusLabel.setText("");
            syntaxValidityStatusLabel.setText("");
            atomicSyntaxValidityStatusLabel.setText("");
            operatorSyntaxValidityStatusLabel.setText("");
            sdnfValidityStatusLabel.setText("");

        }

        private void setAllLEValidityStatus(String status) {
            bracketsValidityStatusLabel.setText(status);
            syntaxValidityStatusLabel.setText(status);
            atomicSyntaxValidityStatusLabel.setText(status);
            operatorSyntaxValidityStatusLabel.setText(status);

        }

        private void checkExpression() {
            clearAllStatuses();
            if (expressionField.getText().isEmpty())
                return;
            try {
                Tree expressionTree = Parser.valueOf(replaceOperatorsToEngine(expressionField.getText()));
                setAllLEValidityStatus("Yes");

                if (SdnfUtil.isSdnf(expressionTree)) {
                    sdnfValidityStatusLabel.setText("Yes");
                } else {
                    sdnfValidityStatusLabel.setText("No");
                }

            } catch (InvalidBracketsException e) {
                bracketsValidityStatusLabel.setText("No");
            } catch (InvalidSyntaxCharacterException e) {
                bracketsValidityStatusLabel.setText("Yes");
                syntaxValidityStatusLabel.setText("No -- " + e.getInvalidCharacter());
            } catch (InvalidAtomicExpressionSyntaxException e) {
                bracketsValidityStatusLabel.setText("Yes");
                syntaxValidityStatusLabel.setText("Yes");
                atomicSyntaxValidityStatusLabel.setText("No -- " + e.getExpression());
            } catch (InvalidOperatorException e) {
                bracketsValidityStatusLabel.setText("Yes");
                syntaxValidityStatusLabel.setText("Yes");
                atomicSyntaxValidityStatusLabel.setText("Yes");
                operatorSyntaxValidityStatusLabel.setText("No -- " + e.getInvalidOperator());
            }
        }
    }
}
