package org.example.parser;

////////////////////////////////////////////
//Лабораторная работа №1 по дисциплине ЛОИС
//Выполнено студентом группы 921703
//Торопом Никитой Сергеевичем
//Вариант d - проверка правильности СДНФ
//Использованные источники:
//1 - docs.oracle.com
//2 - javatpoint.com
public class ParsedEntity {
    private String firstPart;
    private String secondPart;
    private String operator;

    public String getFirstPart() {
        return firstPart;
    }

    public void setFirstPart(String firstPart) {
        this.firstPart = firstPart;
    }

    public String getSecondPart() {
        return secondPart;
    }

    public void setSecondPart(String secondPart) {
        this.secondPart = secondPart;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }
}
