/////////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине ЛОИС
// Вариант С: Проверить, является ли формула СКНФ
// Выполнена студентом группы 921703 Занберовой Ириной Алексеевной
// Класс предназначен для обработки (проверки) формул и формирования сообщения


import java.util.*;

public class Handler {
    private final String verifiable_expression, separator_sign = "/\\";
    private String out;
    private ExpressionTree tree;
    private final Set<String> atoms;

    private final List<String> elementary_disjunctions;

    public static final List <String> symbols = new ArrayList<>(Arrays.asList("A", "B", "C", "D", "E", "F", "G",
            "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"));
    // Полный список знаков
    public static final List<String> all_signs = new ArrayList<>(Arrays.asList("!", "/\\", "\\/", "(", ")", "->", "~"));
    // Список не используемых знаков для элементарных дизъюнкций СКНФ
    public static final List<String> prohibited_signs = new ArrayList<>(Arrays.asList("->", "~", "/\\"));

    public Handler(String expression) {
        this.verifiable_expression = expression;
        atoms = new HashSet<>();
        elementary_disjunctions = new ArrayList<>();
        out = "";
        try {
            check_used_symbols();
            check_brackets();
            tree = new ExpressionTree(expression, this);
            search_elementary_disjunctions();
            verifying_inversions(tree, 0);
            check_elementary_disjunctions_for_number_of_elements();
            verification_of_elementary_disjunction_operations();
            checking_the_uniqueness_of_elementary_disjunctions();
            out = "Эта формула - СКНФ!";

        } catch (ExpressionException ExpressionException) {
            out = "Эта формула - не СКНФ!\n";
            out += ExpressionException.getMessage();
        }
    }

    private void search_elementary_disjunctions() throws ExpressionException {
        excretion_elementary_disjunctions(tree);
        if (elementary_disjunctions.size() != elementary_disjunctions.stream().distinct().count())
            throw new ExpressionException(7);
    }

    private void excretion_elementary_disjunctions(ExpressionTree tree) {
        if (separator_sign.equals(tree.getOperation())) {
            excretion_elementary_disjunctions(tree.getLeft());
            excretion_elementary_disjunctions(tree.getRight());
        }
        else elementary_disjunctions.add(tree.getExpression());
    }

    private void check_used_symbols() throws ExpressionException {
        if (verifiable_expression.length() == 1)
            if (!symbols.contains(verifiable_expression)) throw new ExpressionException(6);
        for (int i = 0; i < verifiable_expression.length(); i++) {
            if (!(symbols.contains("" + verifiable_expression.charAt(i)) || all_signs.contains("" + verifiable_expression.charAt(i)))){
                if(i + 1 < verifiable_expression.length()) {
                    String sign = "" + verifiable_expression.charAt(i) + verifiable_expression.charAt(i + 1);
                    if (all_signs.contains(sign))
                        i++;
                    else throw new ExpressionException(6);
                }
                else throw new ExpressionException(6);
            }
        }
    }

    private void check_brackets() throws ExpressionException {
        if (verifiable_expression.contains(")(") || verifiable_expression.charAt(0) == ')' ||
                (verifiable_expression.charAt(0) != '(' && verifiable_expression.length() != 1) ||
                (verifiable_expression.charAt(0) == '(' && verifiable_expression.charAt(verifiable_expression.length() - 1) != ')'))
            throw new ExpressionException(3);
        int brackets = 0;
        for (int i = 0; i < verifiable_expression.length(); i++) {
            if (verifiable_expression.charAt(i) == '(') brackets++;
            else if (verifiable_expression.charAt(i) == ')') brackets--;
        }
        if (brackets != 0)
            throw new ExpressionException(3);
    }

    private void verifying_inversions(ExpressionTree tree, int mode) throws ExpressionException {
        if (mode == 0) {
            if ("!".equals(tree.getOperation())) {
                if (Objects.isNull(tree.getRight())) {
                    verifying_inversions(tree.getLeft(), 1);
                    return;
                } else
                    throw new ExpressionException(4);
            }
            if (tree.getLeft() != null)
                verifying_inversions(tree.getLeft(), 0);
            if (tree.getRight() != null)
                verifying_inversions(tree.getRight(), 0);
        } else {
            if (tree.getRight() != null)
                throw new ExpressionException(4);
            if ("!".equals(tree.getOperation()))
                throw new ExpressionException(2);
            if (tree.getLeft() != null)
                verifying_inversions(tree.getLeft(), 1);
        }
    }

    private void check_elementary_disjunctions_for_number_of_elements() throws ExpressionException {
        for (String element : elementary_disjunctions)
            for (String atom : atoms) {
                if (!element.contains(atom))
                    throw new ExpressionException(5);
                int count = 0;
                for (int i = 0; i < element.length(); i++)
                    if (atom.equals("" + element.charAt(i)))
                        count++;
                if (count > 1) throw new ExpressionException(8);
            }
    }

    private void verification_of_elementary_disjunction_operations() throws ExpressionException {
        for (String element : elementary_disjunctions)
            for (String sign : prohibited_signs)
                if (element.contains(sign))
                    throw new ExpressionException(1);
    }

    private void checking_the_uniqueness_of_elementary_disjunctions() throws ExpressionException {
        if (elementary_disjunctions.size() != elementary_disjunctions.stream().distinct().count())
            throw new ExpressionException(7);

        List<List<String>> elements = new ArrayList<>(new ArrayList<>());
        for (String element : elementary_disjunctions) {
            List<String> temp_list = new ArrayList<>();
            for (int j = 0; j < element.length(); j++) {
                String temp = "" + element.charAt(j);
                if ("!".equals(temp)) {
                    j++;
                    temp += element.charAt(j);
                }
                if (symbols.contains(""+ element.charAt(j)))
                    temp_list.add(temp);
            }
            elements.add(temp_list);
        }
        //System.out.println(elements);
        for (int i = 0; i < elements.size() - 1; i++)
            for (int j = 0; j < elements.size(); j++) {
                if (i != j && (elements.get(i).containsAll(elements.get(j))))
                    throw new ExpressionException(7);
            }

    }

    public String getOut() {
        return out;
    }

    public void addAtom(String atom) {
        atoms.add(atom);
    }

    public List<String> getElementary_disjunctions() {
        return elementary_disjunctions;
    }
}
