/////////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине ЛОИС
// Вариант С: Проверить, является ли формула СКНФ
// Выполнена студентом группы 921703 Занберовой Ириной Алексеевной
// Класс предназначен для обеспечения прерывания работы Handler при
// нахождении ошибки и передачи информации о типе найденной ошибки
//
// https://ru.stackoverflow.com/questions/934906/
//

public class ExpressionException extends Exception {
    private String message;
    private int error_number;

    public ExpressionException(int id) {
        this.error_number = id;
        this.message = get_error_message();
    }

    private String get_error_message(){
        switch (this.error_number) {
            case 1:
                return "Элементарная дизъюнкция включает операции не соответвующие дизъюнкции или инверсии (для СКНФ)";
            case 2:
                return "Двойная инверсия";
            case 3:
                return "Нарушен синтаксис";
            case 4:
                return "Отрицание не связано с элементом";
            case 5:
                return "Дизъюнкция не состоит из всех переменных в списке";
            case 6:
                return "Используется неизвестный символ";
            case 7:
                return "Дублирующая элементарная дизъюнкция";
            case 8:
                return "Атомы повторяются в дизъюнкции";
        }
        return "";
    }

    public int getError_number() {
        return error_number;
    }

    public String getMessage() {
        return message;
    }
}
