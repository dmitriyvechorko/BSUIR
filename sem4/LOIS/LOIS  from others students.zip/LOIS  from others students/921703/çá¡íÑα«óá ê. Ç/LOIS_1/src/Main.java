/////////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине ЛОИС
// Вариант С: Проверить, является ли формула СКНФ
// Выполнена студентом группы 921703 Занберовой Ириной Алексеевной
// Класс предназначен для поиска формул, их передачи в класс Handler
// и вывода результата обработки
// Ссылки на использованные источники: https://knowledge.allbest.ru/programming/2c0a65625b3ac78b4d43a88521206d37_0.html
//https://studbooks.net/2274337/informatika/razrabotka_programmy_resheniya_zadachi
//Благодарность за помощь в разработке Тесловскому А.П. (GitHub ARtoriouSs)
//


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static final List<String> FILE_NAMES = new ArrayList<>(Arrays.asList("1.txt", "2.txt", "3.txt", "4.txt"));
    private static final String FILE_PATH = System.getProperty("user.dir") + "/tests/";

    public static void main(String[] args) throws IOException {
        for (int i = 0; i < FILE_NAMES.size(); i++) {
            String expression = "";
            StringBuilder builder = new StringBuilder("");
            try (FileInputStream file = new FileInputStream(FILE_PATH + FILE_NAMES.get(i))) {
                while (file.available() > 0)
                    builder.append((char) file.read());
                expression = builder.toString();
            } catch (FileNotFoundException ex) {
                System.out.println("Файл не найден!");
            }
            if(expression.length() > 0) {
                Handler handler = new Handler(expression);
                System.out.println('\n' + expression + '\n' + handler.getOut() + '\n');
            } else System.out.println("Пустая строка!");
        }
    }
}
