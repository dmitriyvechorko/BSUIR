/////////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине ЛОИС
// Вариант С: Проверить, является ли формула СКНФ
// Выполнена студентом группы 921703 Занберовой Ириной Алексеевной
// Класс предназначен для преобразования формулы в дерево выражений (состоящее из
// подформул, их атомов и операций)
//
// https://askdev.ru/q/razbor-arifmeticheskogo-vyrazheniya-i-postroenie-dereva-iz-nego-v-java-84222/
// https://javatalks.ru/topics/18478
// https://javarush.ru/groups/posts/3111-strukturih-dannihkh-dvoichnoe-derevo-v-java


import java.beans.Expression;

public class ExpressionTree {
    private String expression;
    private String operation;
    private ExpressionTree left;
    private ExpressionTree right;
    private final Handler root;

    public ExpressionTree(String expression, Handler root) throws ExpressionException {
        this.expression = expression;
        this.root = root;
        try {
            expand_expression();
        } catch (ExpressionException expressionException) {
            throw new ExpressionException(expressionException.getError_number());
        }
    }

    private void expand_expression() throws ExpressionException {
        if (expression.length() == 0)
            throw new ExpressionException(3);

        if (expression.length() == 1) {
            left = right = null;
            if (!"1".equals(expression) && !"0".equals(expression))
                root.addAtom(expression);
            return;
        }
        if (expression.charAt(0) == '!') {
            this.operation = "!";
            right = null;
            left = new ExpressionTree(copy(expression, 1, expression.length()), root);
            return;
        }
        if (expression.charAt(0) == '(' && expression.charAt(expression.length() - 1) == ')') {
            String expression = copy(this.expression, 1, this.expression.length() - 1);
            if(expression.length() == 1)
                throw new ExpressionException(2);
            int pointerSign = search_sign_outside_brackets(expression);
            if (pointerSign == 0) {
                if(expression.charAt(pointerSign) != '!'){
                    throw new ExpressionException(2);
                }
                right = null;
                left = new ExpressionTree(copy(expression, 1, expression.length()), root);
                operation = search_sign(expression, pointerSign);
                return;
            }
            if (pointerSign == -1)
                throw new ExpressionException(2);
            operation = search_sign(expression, pointerSign);
            String leftExpression = copy(expression, 0, pointerSign);
            if (operation.length() == 2)
                pointerSign += 1;
            String rightExpression = copy(expression, pointerSign + 1, expression.length());
            left = new ExpressionTree(leftExpression, root);
            right = new ExpressionTree(rightExpression, root);
        } else {
            throw new ExpressionException(2);
        }
    }

    private String copy(String str, int start, int end) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = start; i < end; i++)
            stringBuilder.append(str.charAt(i));
        return stringBuilder.toString();
    }

    private int search_sign_outside_brackets(String expression) throws ExpressionException {
        int check = 0;
        for (int i = 0; i < expression.length(); i++) {
            if (check == 0 && expression.charAt(i) != '(' && expression.charAt(i) != ')'
                    && Handler.all_signs.contains(search_sign(expression, i)))
                return i;
            else if (expression.charAt(i) == '(')
                check++;
            else if (expression.charAt(i) == ')')
                check--;
        }
        throw new ExpressionException(3);
    }

    private String search_sign(String expression, int pointer) throws ExpressionException {
        if (expression.charAt(pointer) == '!' || expression.charAt(pointer) == '~')
            return expression.charAt(pointer) + "";
        return "" + expression.charAt(pointer) + expression.charAt(pointer + 1);

    }


    public String getExpression() {
        return expression;
    }

    public ExpressionTree getLeft() {
        return left;
    }

    public ExpressionTree getRight() {
        return right;
    }

    public String getOperation() {
        return operation;
    }
}