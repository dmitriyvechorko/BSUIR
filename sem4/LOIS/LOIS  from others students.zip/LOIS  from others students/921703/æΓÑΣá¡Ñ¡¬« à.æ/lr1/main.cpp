////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл main.cpp содержит методы для взаимодействия с пользователем
// 15.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность за помощь в написании кода выражается Тищенко Виталию Николаевичу

#include <iostream>
#include <cstdio>
#include <cstring>

#include "source/SDNFRecognizer.h"
#include "source/FormulaRecognizer.h"

using namespace std;

const char *optionToExit = "EXIT";

int main() {
    string line;
    FormulaRecognizer formulaRecognizer = FormulaRecognizer();
    SDNFRecognizer sdnfRecognizer = SDNFRecognizer();

    while (strcmp(line.c_str(), optionToExit) != 0) {
        printf("Enter line of text! To exit print %s\n", optionToExit);
        getline(cin, line);
        if (strcmp(line.c_str(), optionToExit) == 0) {
            printf("Exit requested....\n");
            continue;
        }
        if (line.empty()) {
            continue;
        }

        if (formulaRecognizer.isFormula(line)) {
            try {
                printf("%s is formula\n", line.c_str());
                if (sdnfRecognizer.isSDNF(line)) {
                    printf("%s is SDNF\n", line.c_str());
                } else {
                    printf("%s is not SDNF\n", line.c_str());
                }
            }
            catch (runtime_error &e) {
                printf("%s, so it isn't SDNF.\n", e.what());
            }
        } else {
            printf("%s is not formula\n", line.c_str());
        }
    }
    return 0;
}