////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл Formula.h содержит описание класса Formula
// 15.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#ifndef Formula_h
#define Formula_h
#include <string>
#include <stdexcept>
#include <utility>
using namespace std;


class Formula
{
public:
	explicit Formula(string formulaPattern) {
		pattern = string(std::move(formulaPattern));
		amountOfVarsInPattern = 0;
		for (char i : pattern) {
			if (i == '?') {
				amountOfVarsInPattern++;
			}
		}
	}

	int length();
	int amountOfVars() const;
	int indexOfVar(int varIndex);
	int indexOfConnector();
	int charAt(int pos);
	bool stringMatchPattern(string test);

	static const Formula LITERAL;
	static const Formula NEGATION;
	static const Formula DISJUNCTION;
	static const Formula CONJUNCTION;
	static const Formula IMPLICATION;
	static const Formula EQUIVALENCE;


private:
	string pattern;
	int amountOfVarsInPattern;
	static bool isVariable(char possibleVariable) {
		return (possibleVariable >= '0' && possibleVariable <= '1') || (possibleVariable >= 'A' && possibleVariable <= 'Z') || possibleVariable == '?';
	}
};


#endif // !Formula_h

