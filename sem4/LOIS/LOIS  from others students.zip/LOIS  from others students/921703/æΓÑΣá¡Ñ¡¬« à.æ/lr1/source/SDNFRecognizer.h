////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл SDNFRecognizer.h содержит описание класса, отвечающего за определение, является ли введенная формула СДНФ
// 19.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#ifndef LR1_SDNFRECOGNIZER_H
#define LR1_SDNFRECOGNIZER_H

#include <string>
#include <vector>
#include <algorithm>
#include <stdexcept>

#include "exceptions/IllegalCharactersInSDNFException.h"
#include "exceptions/IllegalSyntaxInNegationException.h"
#include "exceptions/IllegalSyntaxInConjunctionException.h"
#include "exceptions/IllegalSyntaxInDisjunctionException.h"
#include "exceptions/RepeatingVariableInSummandException.h"
#include "Formula.h"

using namespace std;

class SDNFRecognizer {
public:
    SDNFRecognizer() = default;

    bool isSDNF(string);

private:
    string backUp;
    vector<char *> fullTruthTable;
    const string LEGAL_CHARACTERS = "!()/\\ABCDEFGHIJKLMNOPQRSTUVWXYZ";


    void printTable() {
        printf("ABCDEFGHIJKLMNOPQRSTUVWXYZ\n");
        for (auto &i: fullTruthTable) {
            printf("%s\n", i);
        }
    }


    void addNegation(char variable) {
        setVariableInTruthTable(variable, 'F');
    }

    void addStatement(char variable) {
        setVariableInTruthTable(variable, 'T');
    }

    void setVariableInTruthTable(char variable, char newValue) {
        char *row = fullTruthTable.at(fullTruthTable.size() - 1);
        int index = variable - 'A';
        if (row[index] != '0') {
            throw RepeatingVariableInSummandException(string(1, variable));
        }
        row[index] = newValue;
    }

    friend void removeNegationsInSummand(SDNFRecognizer &, int &, int &);

    friend void removeConjunctionsInSummand(SDNFRecognizer &, int &, int &);

    friend void removeRemainingDisjunctions(SDNFRecognizer &, int, int);

    friend void negationStartsAt(SDNFRecognizer &, int);

    friend void conjunctionStartsAt(SDNFRecognizer &, int);

    friend void disjunctionStartsAt(SDNFRecognizer &, int);

    friend void literalStartsAt(SDNFRecognizer &, int);
};

#endif //LR1_SDNFRECOGNIZER_H
