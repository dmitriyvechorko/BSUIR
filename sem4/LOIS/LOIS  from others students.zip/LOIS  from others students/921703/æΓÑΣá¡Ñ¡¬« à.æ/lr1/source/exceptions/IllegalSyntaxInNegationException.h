////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл IllegalSyntaxInNegationException.h содержит описание ошибки несоответствия отрицания форме, требуемой для СДНФ
// 19.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#ifndef IllegalSyntaxInNegationException_h
#define IllegalSyntaxInNegationException_h

#include <stdexcept>
#include <string>

using std::runtime_error;

class IllegalSyntaxInNegationException :
        public runtime_error {
public:
    explicit IllegalSyntaxInNegationException(const std::string &illegalSequence) : runtime_error(
            "Negation does not match template for SDNF. Expected (![A-Z]) but found " + illegalSequence) {}

    IllegalSyntaxInNegationException() : runtime_error("attempted to add fourth creature in one cell") {}
};


#endif // !IllegalSyntaxInNegationException_h


