////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл SDNFRecognizer.cpp содержит реализацию методов класса, отвечающего за определение, является ли введенная формула СДНФ
// 19.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#include "SDNFRecognizer.h"

#include <utility>
#include <cstring>

bool containsEqualRows(const vector<char *> &);

bool allRowsContainSameVariables(vector<char *>);

void sortCharArraysVector(vector<char *> &);

char *zeros(int n);

bool SDNFRecognizer::isSDNF(string line) {
    bool isSdnf = false;
    fullTruthTable.clear();

    backUp = std::move(line);
    for (size_t i = 0; i < backUp.size(); i++) {
        int pos = LEGAL_CHARACTERS.find(backUp.at(i));
        if (pos < 0) {
            throw IllegalCharactersInSDNFException(backUp.substr(i, backUp.size() - i));
        }
    }
    int previousDisjunction = 0;
    string disjunctionConnector = "\\/";
    int nextDisjunction = backUp.find(disjunctionConnector);
    if (nextDisjunction < 0) {
        nextDisjunction = backUp.length() - 1;
    }
    while (previousDisjunction < nextDisjunction) {
        fullTruthTable.push_back(zeros('Z' - 'A' + 1));
        removeNegationsInSummand(*this, previousDisjunction, nextDisjunction);
        removeConjunctionsInSummand(*this, previousDisjunction, nextDisjunction);
        previousDisjunction = nextDisjunction + 2;
        nextDisjunction = backUp.find(disjunctionConnector, nextDisjunction + 1);
        if (nextDisjunction < 0) {
            nextDisjunction = backUp.length();
        }
    }
    removeRemainingDisjunctions(*this, 0, backUp.length());
    Formula literal = Formula::LITERAL;
    if (!containsEqualRows(fullTruthTable) && allRowsContainSameVariables(fullTruthTable) &&
        literal.stringMatchPattern(backUp)) {
        isSdnf = true;
    }

//    printTable();
    return isSdnf;
}

void removeNegationsInSummand(SDNFRecognizer &recognizer, int &beginOfSummand, int &endOfSummand) {
    Formula negation = Formula::NEGATION;
    for (size_t i = beginOfSummand; i < endOfSummand; i++) {
        int forwardShift = i + negation.indexOfConnector();
        if (forwardShift < recognizer.backUp.size() && negation.stringMatchPattern(recognizer.backUp.substr(i,
                                                                                                            negation.length()))) {
            negationStartsAt(recognizer, i);
            endOfSummand -= (negation.length() - 1);
            i--;
        }
    }
}

void removeConjunctionsInSummand(SDNFRecognizer &recognizer, int &beginOfSummand, int &endOfSummand) {
    Formula conjunction = Formula::CONJUNCTION;
    int indexOfConnector = conjunction.indexOfConnector();
    int removedConjunctions = 0;
    bool possibleConjunctionIsInSummand = true;
    while (possibleConjunctionIsInSummand) {
        possibleConjunctionIsInSummand = false;
        for (size_t i = beginOfSummand; i < endOfSummand; i++) {
            int shift = i - indexOfConnector;
            int remaining = i + (conjunction.length() - indexOfConnector - 1);
            if (shift >= 0 && remaining < recognizer.backUp.size() && conjunction.stringMatchPattern(
                    recognizer.backUp.substr(shift,
                                             conjunction.length())) /*recognizer.backUp.at(i) == conjunction.charAt(indexOfConnector) && recognizer.backUp.at(i + 1) == conjunction.charAt(indexOfConnector + 1) && recognizer.backUp.at(i - indexOfConnector) == conjunction.charAt(0) && recognizer.backUp.at(i + conjunction.length() - indexOfConnector - 1) == conjunction.charAt(conjunction.length()-1)*/) {
                conjunctionStartsAt(recognizer, shift);
                i = shift;
                endOfSummand -= (conjunction.length() - 1);
                removedConjunctions++;
                possibleConjunctionIsInSummand = true;
            }
        }
    }
    if (removedConjunctions == 0) {
        for (size_t i = beginOfSummand; i < endOfSummand; i++) {
            if (recognizer.backUp.at(i) >= 'A' && recognizer.backUp.at(i) <= 'Z') {
                literalStartsAt(recognizer, i);
            }
        }
    }
}

void removeRemainingDisjunctions(SDNFRecognizer &recognizer, int beginOfSummand, int endOfSummand) {
    Formula disjunction = Formula::DISJUNCTION;
    int indexOfConnector = disjunction.indexOfConnector();
    bool possibleDisjunctionIsInSummand = true;
    while (possibleDisjunctionIsInSummand) {
        possibleDisjunctionIsInSummand = false;
        for (size_t i = beginOfSummand; i < endOfSummand; i++) {
            int shift = i - indexOfConnector;
            int remaining = i + (disjunction.length() - indexOfConnector - 1);
            if (shift >= 0 && remaining < recognizer.backUp.size() && disjunction.stringMatchPattern(
                    recognizer.backUp.substr(shift,
                                             disjunction.length()))) {// stopped here
                disjunctionStartsAt(recognizer, i - indexOfConnector);
                i = shift;
                endOfSummand -= (disjunction.length() - 1);
                possibleDisjunctionIsInSummand = true;
            }
        }
    }
}

void negationStartsAt(SDNFRecognizer &recognizer, int negationStartsAt) {
    Formula neg = Formula::NEGATION;
    int expectedSubstringLength = neg.length();
    int expectedPositionOfVariable = neg.indexOfVar(0);
    string substring = recognizer.backUp.substr(negationStartsAt, expectedSubstringLength);
    char variable = substring.at(expectedPositionOfVariable);
    recognizer.addNegation(variable);
    recognizer.backUp.erase(negationStartsAt, expectedSubstringLength);
    recognizer.backUp.insert(negationStartsAt, "?");
}

void conjunctionStartsAt(SDNFRecognizer &recognizer, int conjunctionStartsAt) {
    Formula conj = Formula::CONJUNCTION;
    int expectedSubstringLength = conj.length();
    string substring = recognizer.backUp.substr(conjunctionStartsAt, expectedSubstringLength);
    for (size_t i = 0; i < conj.amountOfVars(); i++) {
        char variable = substring.at(conj.indexOfVar(i));
        if (variable != '?') {
            recognizer.addStatement(variable);
        }
    }
    recognizer.backUp.erase(conjunctionStartsAt, expectedSubstringLength);
    recognizer.backUp.insert(conjunctionStartsAt, "?");
}

void disjunctionStartsAt(SDNFRecognizer &recognizer, int disjunctionStartsAt) {
    Formula disj = Formula::DISJUNCTION;
    int expectedSubstringLength = disj.length();
    string substring = recognizer.backUp.substr(disjunctionStartsAt, expectedSubstringLength);
    recognizer.backUp.erase(disjunctionStartsAt, expectedSubstringLength);
    recognizer.backUp.insert(disjunctionStartsAt, "?");
}

void literalStartsAt(SDNFRecognizer &recognizer, int literalStartsAt) {
    Formula lit = Formula::LITERAL;
    int expectedSubstringLength = lit.length();
    string substring = recognizer.backUp.substr(literalStartsAt, expectedSubstringLength);
    char literal = substring.at(lit.indexOfVar(0));
    recognizer.addStatement(literal);
    recognizer.backUp.erase(literalStartsAt, expectedSubstringLength);
    recognizer.backUp.insert(literalStartsAt, "?");
}

bool containsEqualRows(const vector<char *> &truthTable) {
    if (truthTable.size() < 2) {
        return false;
    }
    vector<char *> sorted = truthTable;
    sortCharArraysVector(sorted);
    for (size_t i = 0; i < sorted.size() - 1; i++) {
        if (strcmp(sorted.at(i), sorted.at(i + 1)) == 0) {
            return true;
        }
    }
    return false;
}

void sortCharArraysVector(vector<char *> &table) {
    for (size_t i = 0; i < table.size(); i++) {
        for (size_t j = i; j < table.size(); j++) {
            if (strcmp(table.at(i), table.at(j)) > 0) {
                char *temp = table.at(i);
                table.at(i) = table.at(j);
                table.at(j) = temp;
            }
        }
    }

}

bool allRowsContainSameVariables(vector<char *> truthTable) {
    if (truthTable.size() < 2) {
        return true;
    }
    int rowLength = strlen(truthTable.at(truthTable.size() - 1));
    vector<char *> mask;
    for (auto truthTableRow: truthTable) {
        char *maskRow = zeros(rowLength);
        for (size_t j = 0; j < rowLength; j++) {
            maskRow[j] = (truthTableRow[j] != '0') + '0';
        }
        mask.push_back(maskRow);
    }
    sortCharArraysVector(mask);
    return (strcmp(mask.at(0), mask.at(mask.size() - 1)) == 0);
}


char *zeros(int n) {
    char *ans = new char[n + 1];
    for (size_t i = 0; i < n; i++) {
        ans[i] = '0';
    }
    ans[n] = '\0';
    return ans;
}