////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл IllegalCharactersInSDNFException.h содержит описание ошибки ввода символов, которые не могут быть частью СДНФ
// 19.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#ifndef IllegalCharactersInSDNFException_h
#define IllegalCharactersInSDNFException_h

#include <stdexcept>
#include <string>

using std::runtime_error;

class IllegalCharactersInSDNFException :
        public runtime_error {
public:
    explicit IllegalCharactersInSDNFException(const std::string &illegalSequence) : runtime_error(
            "String contains illegal for SDNF characters:" + illegalSequence) {}

    IllegalCharactersInSDNFException() : runtime_error("attempted to add fourth creature in one cell") {}
};


#endif // !IllegalCharactersInSDNFException_h


