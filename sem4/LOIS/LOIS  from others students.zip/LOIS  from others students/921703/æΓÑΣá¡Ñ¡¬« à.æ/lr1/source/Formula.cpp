////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл Formula.cpp содержит реализацию методов класса Formula
// 15.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#include "Formula.h"

const Formula Formula::LITERAL = Formula("?");
const Formula Formula::NEGATION = Formula("(!?)");
const Formula Formula::CONJUNCTION = Formula("(?/\\?)");
const Formula Formula::DISJUNCTION = Formula("(?\\/?)");
const Formula Formula::IMPLICATION = Formula("(?->?)");
const Formula Formula::EQUIVALENCE = Formula("(?~?)");


int Formula::length() {
    return pattern.length();
}

int Formula::amountOfVars() const {
    return amountOfVarsInPattern;
}

int Formula::indexOfVar(int varIndex) {
    if (varIndex < 0 || varIndex >= amountOfVarsInPattern) {
        return -1;
    }
    int varsAlreadySeen = -1;
    for (size_t i = 0; i < pattern.length(); i++) {
        if (pattern.at(i) == '?') {
            varsAlreadySeen++;
        }
        if (varsAlreadySeen == varIndex) {
            return i;
        }
    }
    return -1;
}

int Formula::indexOfConnector() {
    for (int i = 0; i < pattern.length(); i++) {
        char symbol = pattern.at(i);
        if (symbol != '(' && symbol != ')' && symbol != '?') {
            return i;
        }
    }
    return -1;
}

int Formula::charAt(int pos) {
    if (pos >= pattern.length() || pos < 0) {
        throw runtime_error(string(&"index is wrong:" [ pos]));
    }
    return pattern.at(pos);
}

bool Formula::stringMatchPattern(string test) {
    if (test.length() != pattern.length()) {
        return false;
    }
    int seenVariablesInTest = 0;
    for (size_t i = 0; i < test.length(); i++) {
        char inTest = test.at(i);
        char inPattern = pattern.at(i);
        if (!isVariable(inTest) && inTest == inPattern) {
            continue;
        }
        if (isVariable(inTest) && indexOfVar(seenVariablesInTest) == i) {
            seenVariablesInTest++;
        } else {
            return false;
        }
    }
    return seenVariablesInTest == amountOfVarsInPattern;
}