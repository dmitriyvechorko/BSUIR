////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл IllegalSyntaxInConjunctionException.h содержит описание ошибку несоответствия конъюнкций форме, требуемой для СДНФ
// 19.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#ifndef IllegalSyntaxInConjunctionException_h
#define IllegalSyntaxInConjunctionException_h

#include <stdexcept>
#include <string>

using std::runtime_error;

class IllegalSyntaxInConjunctionException :
        public runtime_error {
public:
    explicit IllegalSyntaxInConjunctionException(const std::string &illegalSequence) : runtime_error(
            "Conjunction does not match template for SDNF . Expected ([A-Z?]/\\[A-Z?]) but found " + illegalSequence) {}

    IllegalSyntaxInConjunctionException() : runtime_error("attempted to add fourth creature in one cell") {}
};


#endif // !IllegalSyntaxInConjunctionException_h