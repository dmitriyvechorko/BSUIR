////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл IllegalSyntaxInDisjunctionException.h содержит описание ошибку несоответствия дизъюнкций форме, требуемой для СДНФ
// 19.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#ifndef IllegalSyntaxInDisjunctionException_h
#define IllegalSyntaxInDisjunctionException_h

#include <stdexcept>
#include <string>

using std::runtime_error;

class IllegalSyntaxInDisjunctionException :
        public runtime_error {
public:
    explicit IllegalSyntaxInDisjunctionException(const std::string &illegalSequence) : runtime_error(
            "Disjunction does not match template for SDNF. Expected ([A-Z?]\\/[A-Z?]) but found " + illegalSequence) {}

    IllegalSyntaxInDisjunctionException() : runtime_error("attempted to add fourth creature in one cell") {}
};


#endif // !IllegalSyntaxInDisjunctionException_h