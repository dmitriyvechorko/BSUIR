////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл RepeatingVariableInSummandException.h содержит  описание ошибки повтора подформул в элементарных конъюнкциях
// 19.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#ifndef RepeatingVariableInSummandException_h
#define RepeatingVariableInSummandException_h

#include <stdexcept>
#include <string>

using std::runtime_error;

class RepeatingVariableInSummandException :
        public runtime_error {
public:
    explicit RepeatingVariableInSummandException(const std::string &illegalSequence) : runtime_error(
            "Summation has repeating variable " + illegalSequence) {}

    RepeatingVariableInSummandException() : runtime_error("attempted to add fourth creature in one cell") {}
};


#endif // !RepeatingVariableInSummandException_h


