////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл FormulaRecognizer.h содержит описание класса, отвечающего за определение, является ли введенная строка формулой
// 16.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#ifndef FormulaRecognizer_h
#define FormulaRecognizer_h

#include <string>
#include <vector>
#include <algorithm>
#include <stdexcept>

#include "exceptions/IllegalSyntaxInNegationException.h"
#include "Formula.h"

using namespace std;

class FormulaRecognizer {
public:
    FormulaRecognizer() {}

    bool isFormula(string text);
    bool AllSymbolsAreFromAlphabet(const string& line, const string& alphabet);

private:
    string backUp;
    const string LEGAL_CHARACTERS = "!()/\\~->ABCDEFGHIJKLMNOPQRSTUVWXYZ10";

    friend void startRecognition(FormulaRecognizer &);
};


#endif // !FormulaRecognizer_h

