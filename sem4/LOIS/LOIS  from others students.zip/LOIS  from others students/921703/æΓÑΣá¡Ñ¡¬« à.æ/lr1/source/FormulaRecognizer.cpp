////////////////////////////////////////////////////////////////////////////////////
// Лабораторная работа №1 по дисциплине Логические Основы Интеллектуальных Систем
// Выполнена студенткой группы 921703 БГУИР Стефаненко Екатериной Сергеевной
// Файл FormulaRecognizer.cpp содержит реализацию методов класса, отвечающего за определение, является ли введенная строка формулой
// 16.04.2022

// Использованные источники:
// Справочная система по дисциплине ЛОИС

// Особая благодарность выражается Тищенко Виталию Николаевичу

#include "FormulaRecognizer.h"

bool checkIfBracesAreBalanced(const std::string &text);

bool FormulaRecognizer::AllSymbolsAreFromAlphabet(const string& line, const string& alphabet){
    bool allAreLegal = true;
    size_t pos;
    for (size_t i = 0; i < line.size(); i++){
        pos = alphabet.find(line.at(i));
        if (pos < 0){
            allAreLegal = false;
            break;
        }
    }
    return allAreLegal;
}

bool FormulaRecognizer::isFormula(string line) {
    bool isFormula = false;
    backUp = line;

    try {
        bool allSymbolsAreFromAlphabet = AllSymbolsAreFromAlphabet(backUp, LEGAL_CHARACTERS);
        if (!allSymbolsAreFromAlphabet) {
                throw runtime_error("Illegal character! Check the alphabet.\n");
        }
        if (!checkIfBracesAreBalanced(backUp)) {
            throw runtime_error("Braces are not balanced");
        }
        startRecognition(*this);
        Formula literal = Formula::LITERAL;
        if (literal.stringMatchPattern(backUp)) {
            isFormula = true;
        }
    }
    catch (const runtime_error &e) {
    }

    return isFormula;
}

void startRecognition(FormulaRecognizer &recognizer) {
    bool possibleFormulaIsInLine = true;
    string wildCard = "?";
    while (possibleFormulaIsInLine) {
        possibleFormulaIsInLine = false;
        for (size_t i = 0; i < recognizer.backUp.size(); i++) {
            char currentSymbol = recognizer.backUp.at(i);
            Formula currentFormula("");
            switch (currentSymbol) {
                case '!': {
                    currentFormula = Formula::NEGATION;
                    break;
                }
                case '/': {
                    currentFormula = Formula::CONJUNCTION;
                    break;
                }
                case '\\': {
                    currentFormula = Formula::DISJUNCTION;
                    break;
                }
                case '-': {
                    currentFormula = Formula::IMPLICATION;
                    break;
                }
                case '~': {
                    currentFormula = Formula::EQUIVALENCE;
                    break;
                }
                default:
                    continue;
            }
            int expectedLength = currentFormula.length();
            int startOfFormula = i - currentFormula.indexOfConnector();
            if (startOfFormula < 0) {
                throw runtime_error("Illegal formula syntax. Not enough symbols before connector");
            }
            string substring = recognizer.backUp.substr(startOfFormula, expectedLength);
            if (currentFormula.stringMatchPattern(substring)) {
                possibleFormulaIsInLine = true;
                recognizer.backUp.erase(startOfFormula, expectedLength);
                recognizer.backUp.insert(startOfFormula, wildCard);
            }

        }
    }
}

bool checkIfBracesAreBalanced(const std::string &text) {
    int level = 0;
    for (char i: text) {
        if (i == '(') {
            level++;
        } else if (i == ')') {
            level--;
        }
        if (level < 0) {
            return false;
        }
    }
    return (level == 0);
}
