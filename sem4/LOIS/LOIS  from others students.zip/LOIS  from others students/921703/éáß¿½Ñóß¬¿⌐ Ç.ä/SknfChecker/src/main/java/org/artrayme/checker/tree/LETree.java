package org.artrayme.checker.tree;

////////////////////////////////////////////
//Лабораторная работа №1-2 по дисциплине ЛОИС
//Выполнено студентом группы 921703
//Василевский Артемий Дмитриевич
//Использованные источники:
//1) Справочно система по дисциплине ЛОИС
public class LETree {
    private final LENode root;

    public LETree(LENode root) {
        this.root = root;
    }

    public LENode getRoot() {
        return root;
    }

}
