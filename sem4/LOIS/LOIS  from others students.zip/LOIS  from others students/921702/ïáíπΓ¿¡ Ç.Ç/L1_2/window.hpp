#ifndef WINDOW_HPP
#define WINDOW_HPP

#include <QtWidgets>
#include <QPushButton>
#include <QMap>
#include "formula.hpp"

class Window;

class Popup : public QWidget {
	Q_OBJECT

public:
	explicit Popup(Window* window,
				   void (Window::*eval)(const QMap<QChar, bool>&, const QString&),
				   QWidget *parent = 0);
	void requestVariables(const QString& str);
private slots:
	void submit();

//	void evaluateButton();

private:
	void clearModel();
	Window *m_Window;
	QTableView *m_ResultView = new QTableView();
	QPushButton *m_CheckButton = new QPushButton("Решить", this);
	QString m_Str;

	QHBoxLayout *m_QueryLayout = new QHBoxLayout();
	QVBoxLayout *m_MainLayout = new QVBoxLayout();
	void (Window::*m_Evaluate)(const QMap<QChar, bool>&, const QString&);
	QStandardItemModel m_Model;
	QMap<QChar, bool> m_Map;
};

class Window : public QWidget {
	Q_OBJECT

public:
	explicit Window(QWidget *parent = 0);
	void addCheckedLine(bool);
	void evaluate(const QMap<QChar, bool>& map, const QString& str);

private slots:
	void checkButton();

	void evaluateButton();

private:
	QLabel *m_QueryLabel = new QLabel(QApplication::translate("nestedlayouts", "Formula:"));
	QLineEdit *m_QueryEdit = new QLineEdit();
	QTableView *m_ResultView = new QTableView();
	QTableView *m_ValidityView = new QTableView();
	QPushButton *m_CheckButton = new QPushButton("Проверить", this);
	QPushButton *m_EvaluateButton = new QPushButton("Решить", this);

	QHBoxLayout *m_QueryLayout = new QHBoxLayout();
	QVBoxLayout *m_MainLayout = new QVBoxLayout();
	QStandardItemModel m_ModelLine;
	QStandardItemModel m_Model;
	Popup m_Popup = Popup(this, &Window::evaluate);
};
#endif // WINDOW_HPP
