#include "formula.hpp"
#include <QStack>
#include <QPair>
#include <iostream>

static inline bool isterm(QChar c) {
	return c.isUpper() || c == '1' || c == '0';
}

static QChar exec(bool l, QChar o, bool r) {
	switch(o.toLatin1()) {
		case '!':
			return !r;
		break; case '/':
			return l && r;
		break; case '\\':
			return l || r;
		break; case '-':
			return l <= r;
		break; case '~':
			return l == r;
	}
	throw 1;
}

static inline bool should_exec(const QStack<QPair<QChar, int>>& stack) {
	if ((stack.length() < 3) || ((++stack.rbegin())->second != stack.top().second))
		return 0;
	QChar d = (stack.rbegin() + 2)->first;
	char dd = d.toLatin1();
	return ((stack.rbegin() + 2)->first.toLatin1() < 2)
			&& (stack.top().first.toLatin1() < 2);
}

static inline void try_exec(QStack<QPair<QChar, int>>& stack) {
	while (should_exec(stack)) {
		QChar r = stack.pop().first;
		QChar o = stack.pop().first;
		QChar l = stack.top().first;
		int l_d = stack.pop().second;
		stack.push_back({exec(l.toLatin1(), o, r.toLatin1()), l_d - 1});
	}
}
/*
static inline bool finish_exec(const QMap<QChar, bool>& map, QStack<QPair<QChar, int>>& stack) {
	while (stack.size() >= 3) {
		QChar r = stack.back().first;
		QChar o = stack.back().first;
		stack.pop_back();
		QChar l = stack.back().first;
		stack.pop_back();
		stack.push({exec(l.toLatin1(), o, r.toLatin1()), 0});
	}
}
*/

int validate_formula(const QString& str) {
	QStack<int> op_counts;
	if (str.size() == 0)
		return 0;
	int depth = 0;
	enum {
		BEG,//
		TERM,//
		TERM_OR_OPEN,//
		TERM_OR_OPEN2,
		OPERATION,//
		OPERATION_OR_CLOSE,
		OPEN,//
		CLOSE,
		FINISH
	} state = BEG;
	for (auto it = str.begin(); it != str.end(); ++it) {
		const QChar& e = *it;
		switch(state) {
			case BEG: {
				if (isupper(e.toLatin1()) || e == '1' || e == '0') {
					state = FINISH;
				}
				else if (e == '(') {
					op_counts.push(0);
					++depth;
					state = TERM_OR_OPEN;
				}
				else return 0;
			}//BEG
			break; case OPEN: {
				if (e == '(') {
					op_counts.push(0);
					++depth;
					state = TERM_OR_OPEN;
				}
				else return 0;
			}//OPEN
			break; case OPERATION: {
				if (((it + 1 != str.end())
				&& ((e == '/' && *(it + 1) == '\\')
				|| (e == '\\' && *(it + 1) == '/')
				|| (e == '-' && *(it + 1) == '>')))) {
					++op_counts.top();
					++it;
					state = TERM_OR_OPEN2;
				}
				else if (e == '~') {
					++op_counts.top();
					state = TERM_OR_OPEN2;
				}
				else return 0;
			}//OPERATION
			break; case TERM: {
				if (e.isUpper() || e == '1' || e == '0') {
					state = CLOSE;
				}
				else return 0;
			}//TERM
			break; case TERM_OR_OPEN: {
				if (e.isUpper() || e == '1' || e == '0') {
					state = OPERATION;
				}
				else if (e == '(') {
					op_counts.push(0);
					++depth;
					state = TERM_OR_OPEN;
				}
				else if (e == '!') {
					++op_counts.top();
					state = TERM_OR_OPEN2;
				}
				else return 0;
			}//TERM_OR_OPEN
			break; case TERM_OR_OPEN2: {
				if (e.isUpper() || e == '1' || e == '0') {
					if (!depth)
						return 0;
					state = CLOSE;
				}
				else if (e == '(') {
					op_counts.push(0);
					++depth;
					state = TERM_OR_OPEN;
				}
				else return 0;
			}//TERM_OR_OPEN
			break; case CLOSE: {
				if (e == ')') {
					if (op_counts.pop() != 1)
						return 0;
					--depth;
					if (depth)
						state = OPERATION_OR_CLOSE;
					else
						state = FINISH;
				}
				else return 0;
			}//TERM_OR_OPEN
			break; case OPERATION_OR_CLOSE: {
				if ((it + 1 != str.end())
				&& (((e == '/' && *(it + 1) == '\\')
				|| (e == '\\' && *(it + 1) == '/')
				|| (e == '-' && *(it + 1) == '>')))) {
					++op_counts.top();
					++it;
					state = TERM_OR_OPEN2;
				}
				else if (e == '~') {
					++op_counts.top();
					state = TERM_OR_OPEN2;
				}
				else if (e == ')') {
					if (op_counts.pop() != 1)
						return 0;
					--depth;
					if (depth)
						state = OPERATION_OR_CLOSE;
					else
						state = FINISH;
				}
				else return 0;
			}//TERM_OR_OPEN
			break; default:
				return 0;
		}//switch
	}// for
	return !depth;
}

static QChar to_value(QMap<QChar, bool> map, QChar e) {
	auto it = map.find(e);
	if (it == map.end())
		return e;
	return *it;
}

QString evaluate_formula(const QString& str, QMap<QChar, bool> map) {
	QStack<QPair<QChar, int>> stack;
	if (str.size() == 0)
		return "[[invalid]]";
	int depth = 0;
	enum {
		BEG,//
		TERM,//
		TERM_OR_OPEN,//
		TERM_OR_OPEN2,
		OPERATION,//
		OPERATION_OR_CLOSE,
		OPEN,//
		CLOSE,
		FINISH
	} state = BEG;
	for (auto it = str.begin(); it != str.end(); ++it) {
		const QChar& e = *it;
		switch(state) {
			case BEG: {
				if (e.isUpper() || e == '1' || e == '0') {
					auto it = map.find(e);
					if (map.end() != it)
						return QString(*it + '0');
					return e;
				}
				else if (e == '(') {
					++depth;
					state = TERM_OR_OPEN;
				}
				else return "[[invalid]]";
			}//BEG
			break; case OPEN: {
				if (e == '(') {
					++depth;
					state = TERM_OR_OPEN;
				}
				else return "[[invalid]]";
			}//OPEN
			break; case OPERATION: {
				if ((e == '/')
				|| (e == '\\')
				|| (e == '-')) {
					stack.push({e, depth});
					++it;
					state = TERM_OR_OPEN2;
				}
				else if (e == '~') {
					stack.push({e, depth});
					state = TERM_OR_OPEN2;
				}
				else return "[[invalid]]";
			}//OPERATION
			break; case TERM: {
				if (e.isUpper() || e == '1' || e == '0') {
					stack.push({to_value(map, e), depth});
					try_exec(stack);
					state = CLOSE;
				}
				else return "[[invalid]]";
			}//TERM
			break; case TERM_OR_OPEN: {
				if (e.isUpper() || e == '1' || e == '0') {
					stack.push({to_value(map, e), depth});
					state = OPERATION;
				}
				else if (e == '(') {
					++depth;
					state = TERM_OR_OPEN;
				}
				else if (e == '!') {
					stack.push({0, depth});
					stack.push({e, depth});
					state = TERM_OR_OPEN2;
				}
				else return "[[invalid]]";
			}//TERM_OR_OPEN
			break; case TERM_OR_OPEN2: {
				if (e.isUpper() || e == '1' || e == '0') {
					stack.push({to_value(map, e), depth});
					try_exec(stack);
					if (!depth)
						return "[[invalid]]";
					state = CLOSE;
				}
				else if (e == '(') {
					++depth;
					state = TERM_OR_OPEN;
				}
				else return "[[invalid]]";
			}//TERM_OR_OPEN
			break; case CLOSE: {
				if (e == ')') {
					--depth;
					if (depth)
						state = OPERATION_OR_CLOSE;
					else
						state = FINISH;
				}
				else return "[[invalid]]";
			}//TERM_OR_OPEN
			break; case OPERATION_OR_CLOSE: {
				if ((e == '/')
					 || (e == '\\')
					 || (e == '-')) {
					stack.push({e, depth});
					++it;
					state = TERM_OR_OPEN2;
				}
				else if (e == '~') {
					stack.push({e, depth});
					state = TERM_OR_OPEN2;
				}
				else if (e == ')') {
					--depth;
					if (depth)
						state = OPERATION_OR_CLOSE;
					else
						state = FINISH;
				}
				else return "[[invalid]]";
			}//TERM_OR_OPEN
			break; default:
				return "[[invalid]]";
		}//switch
	}// for
	//finish_exec(map, stack);
	if (depth)
		return "[[invalid]]";
//	if (stack.size() != 1)
//		std::cout << "Oups\n";
	QString ret;
	ret.reserve(stack.length() * 2);
	if (str.capacity() > 2) for (const auto& e : stack) {
		while (e.second > depth) {
			++depth;
			ret.append('(');
		}
		while (e.second < depth) {
			--depth;
			ret.append(')');
		}
		char l = e.first.toLatin1();
		switch (l) {
		break; case 0:
			ret.append('0');
		break; case 1:
			ret.append('1');
		break; case '!':
			*ret.rbegin() = '!';
		break; case '/':
			ret.append("/\\");
		break; case '\\':
			ret.append("\\/");
		break; case '-':
			ret.append("->");
		break; case '~':
			ret.append("~");
		break; default:
			ret.append(l);
		}
	}
	else  {
		switch (stack.top().first.toLatin1()) {
			case 0: ret.append('0');
			break; case 1: ret.append('1');
			break; default: ret.append(stack.top().first);
		}
	}
	while (depth) {
		--depth;
		ret.append(')');
	}
	return ret;
}

void extract_variables_from_formula(QMap<QChar, bool>& map, const QString& formula) {
	for (const auto& e : formula) {
		if (e.isUpper()) {
			map.insert(e, 0);
		}
	}
}
