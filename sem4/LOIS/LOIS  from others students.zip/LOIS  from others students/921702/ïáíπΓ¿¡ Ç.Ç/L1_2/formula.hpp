#ifndef FORMULA_HPP
#define FORMULA_HPP

#include <QString>
#include <QMap>
#include <QStandardItem>

int validate_formula(const QString& str);

QString evaluate_formula(const QString& str, QMap<QChar, bool> map);

void extract_variables_from_formula(QMap<QChar, bool>& map, const QString& formula);
#endif // FORMULA_HPP
