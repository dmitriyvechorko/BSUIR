#include "window.hpp"
#include <iostream>
#include <QMap>
#include <QList>

Window::Window(QWidget *parent):QWidget(parent) {
	m_QueryLayout->addWidget(m_QueryLabel);
	m_QueryLayout->addWidget(m_QueryEdit);
	m_QueryLayout->addWidget(m_CheckButton);
	m_QueryLayout->addWidget(m_EvaluateButton);
	m_MainLayout->addLayout(m_QueryLayout);
	m_MainLayout->addWidget(m_ValidityView);
	m_MainLayout->addWidget(m_ResultView);
	m_Model.setHorizontalHeaderLabels(
		QStringList() << QApplication::translate("nestedlayouts", "Формула")
					  << QApplication::translate("nestedlayouts", "Значение"));

	m_ModelLine.setHorizontalHeaderLabels(
		QStringList() << QApplication::translate("nestedlayouts", "Cтрока")
					  << QApplication::translate("nestedlayouts", "Результат"));
	m_ValidityView->setModel(&m_ModelLine);
	m_ValidityView->verticalHeader()->hide();
	m_ValidityView->horizontalHeader()->setStretchLastSection(true);
	m_ResultView->setModel(&m_Model);
	m_ResultView->verticalHeader()->hide();
	m_ResultView->horizontalHeader()->setStretchLastSection(true);
	this->setLayout(m_MainLayout);
	connect(m_CheckButton, &QPushButton::released, this, &Window::checkButton);
	connect(m_EvaluateButton, &QPushButton::released, this, &Window::evaluateButton);
}

void Window::checkButton() {
	addCheckedLine(validate_formula(m_QueryEdit->text()));
}

void Window::evaluateButton() {
	QString formula = m_QueryEdit->text();
	if (!validate_formula(formula))
		return addCheckedLine(0);
	//extract_variables_from_formula(map, formula);
	m_Popup.requestVariables(formula);

}

void Window::addCheckedLine(bool valid) {
	QList<QStandardItem*> items;
	items.append(new QStandardItem(m_QueryEdit->text()));
	items.back()->setEditable(0);
	if (valid)
		items.append(new QStandardItem("Является формулой логики высказываний."));
	else
		items.append(new QStandardItem("Не является формулой логики высказываний."));
	items.back()->setEditable(0);
	m_ModelLine.appendRow(items);
}

void Popup::requestVariables(const QString& str) {
	clearModel();
	QSet<QChar> set;
	//extract_variables_from_formula(m_Map, str);
	QList<QStandardItem*> items;
	for (const auto& e : str) {
		if (isupper(e.toLatin1()))
			set.insert(e);
	}
	for (const auto& e : set) {
		items.append(new QStandardItem(e));
		items.back()->setEditable(0);
		items.append(new QStandardItem(""));
		m_Model.appendRow(items);
		items.clear();
	}
	m_Map.clear();
	m_Map.insert('0', 0);
	m_Map.insert('1', 1);
	m_Str = std::move(str);
	this->show();
}

Popup::Popup(Window *window,
			 void (Window::*eval)(const QMap<QChar, bool>&, const QString&),
			 QWidget *parent):QWidget(parent), m_Window(window), m_Evaluate(eval) {
	m_QueryLayout->addWidget(m_CheckButton);
	m_MainLayout->addLayout(m_QueryLayout);
	m_MainLayout->addWidget(m_ResultView);
	m_Model.setHorizontalHeaderLabels(
		QStringList() << QApplication::translate("nestedlayouts", "Переменная")
					  << QApplication::translate("nestedlayouts", "Значение"));

	m_ResultView->setModel(&m_Model);
	m_ResultView->verticalHeader()->hide();
	m_ResultView->horizontalHeader()->setStretchLastSection(true);
	this->setLayout(m_MainLayout);
	connect(m_CheckButton, &QPushButton::released, this, &Popup::submit);
}

void Popup::submit() {
	hide();
	for (int i = 0, t = m_Model.rowCount(); i != t; ++i) {
		QString str = m_Model.item(i, 1)->text();
		if (str.length() > 1) {
			show();
			return;
		}
		if (str.length() == 1) {
			QChar e = m_Model.item(i, 0)->text()[0];
			switch (str[0].toLatin1()) {
			case '0':
				m_Map[e] = 0;
			break; case '1':
				m_Map[e] = 1;
			break; default:
				m_Map.clear();
				m_Map.insert('0', 0);
				m_Map.insert('1', 1);
				show();
				return;
			}
		}
	}
	static_cast<Window *>(m_Window)->evaluate(m_Map, m_Str);
}

void Popup::clearModel() {
	m_Model.clear();
	m_Model.setHorizontalHeaderLabels(
		QStringList() << QApplication::translate("nestedlayouts", "Переменная")
					  << QApplication::translate("nestedlayouts", "Значение"));
}

void Window::evaluate(const QMap<QChar, bool>& map, const QString& str) {
	QList<QStandardItem*> items;
	items.append(new QStandardItem(str));
	items.append(new QStandardItem(evaluate_formula(std::forward<const QString>(str), map)));
	m_Model.appendRow(items);
}
