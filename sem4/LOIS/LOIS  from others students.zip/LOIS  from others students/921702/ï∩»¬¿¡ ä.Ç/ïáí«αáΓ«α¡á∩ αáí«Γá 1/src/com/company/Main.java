/*
    Лабораторная работа №1 по дисциплине ЛОИС
    Вариант В - Проверить, является ли строка формулой сокращённого языка логики высказываний
    Выполнена студентом группы 921702 БГУИР Ляпкином Дмитрием Андреевичем
    Файл Main, запускающий программу
    15.03.2022
*/
package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nВведите формулу сокращенного языка логики высказываний: ");
            StringBuilder formula = new StringBuilder(scanner.next());
            new Parser(formula);
        }

    }
}
