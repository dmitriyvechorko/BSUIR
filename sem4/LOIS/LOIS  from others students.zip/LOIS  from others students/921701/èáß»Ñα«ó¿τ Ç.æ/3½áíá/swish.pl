% Лабораторная работа 3
% Касперович Александр Сергеевич
% гр. 921701
% Вариант 13
% Тема: Логическое программирование поиска решения задачи
% Цель: Приобрести навыки логического программирования поиска решения задачи.

vertex(⭐).
vertex(🌑).

show([A | [B | C]]) :- show(A),
    				   show(B),
                       show(C),
                       write(" "),
                       nl.

show([A, B, C]) :- write(A),
    		       write(B),
                   write(C),
                   nl.

show([[A, B, C]]) :- write(A),
    		         write(B),
                     write(C),
                     nl.


reverse([], L, L).
reverse([H | T], L, R) :- reverse(T, [H | L], R).

move(Positions, Positions, Steps, Steps) :- !.
move(Current_positions, Final_positions, Steps, Path) :-
    allowed_move(Current_positions, Next_step),
    not(member(Next_step, Steps)),
    move(Next_step, Final_positions, [Next_step | Steps], Path).

begin :-
    Current_positions = [[⭐, 💫, ⭐], [💫, 🚫, 💫], [🌑, 💫, 🌑]],
    Final_positions = [[🌑, 💫, 🌑], [💫, 🚫, 💫], [⭐, 💫, ⭐]],
	Steps = [Current_positions],
    move(Current_positions, Final_positions, Steps, Path),
    reverse(Path, [], Inversed_path), 
    show(Inversed_path).

allowed_move([[X, Q, W], [E, R, Y], [T, U, I]], [[Y, Q, W], [E, R, X], [T, U, I]]) :- free_transition_between(X, Y).
allowed_move([[Q, W, X], [Y, E, R], [T, U, I]], [[Q, W, Y], [X, E, R], [T, U, I]]) :- free_transition_between(X, Y).
allowed_move([[Q, W, E], [R, T, X], [Y, U, I]], [[Q, W, E], [R, T, Y], [X, U, I]]) :- free_transition_between(X, Y).
allowed_move([[Q, W, E], [X, R, T], [U, I, Y]], [[Q, W, E], [Y, R, T], [U, I, X]]) :- free_transition_between(X, Y).
allowed_move([[Q, W, X], [E, R, T], [U, Y, I]], [[Q, W, Y], [E, R, T], [U, X, I]]) :- free_transition_between(X, Y).
allowed_move([[Q, X, W], [E, R, T], [U, I, Y]], [[Q, Y, W], [E, R, T], [U, I, X]]) :- free_transition_between(X, Y).
allowed_move([[Q, X, W], [E, R, T], [Y, U, I]], [[Q, Y, W], [E, R, T], [X, U, I]]) :- free_transition_between(X, Y).
allowed_move([[X, Q, W], [E, R, T], [U, Y, I]], [[Y, Q, W], [E, R, T], [U, X, I]]) :- free_transition_between(X, Y).

free_transition_between(X, Y) :- vertex(X), not(vertex(Y)); vertex(Y), not(vertex(X)).