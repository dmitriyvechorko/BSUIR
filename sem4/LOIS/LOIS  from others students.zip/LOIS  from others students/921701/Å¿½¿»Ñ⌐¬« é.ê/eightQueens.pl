% Лабораторная работа #3
% Выполнил студент группы 921701 БГУИР Пилипейко Валентин Игоревич
% Файл содержит описание предикатов и правил, позволяющих расставаить на шахматной доске 8 ферзей так, чтобы
% ни один ферзь не находился под боем другого

get(S):-
S=[1/_,2/_,3/_,4/_,5/_,6/_,7/_,8/_],
solution(S).

get(S, B):-
S = B,
find(S, Count),
eight(Count),
solution(S).

find([], 0):-!.

find([_Head|Tail], Count):-
find(Tail, TailCount),
Count is TailCount + 1.

eight(8).

solution([]).

solution([X/Y | Others]) :-
solution(Others),
member(Y, [1, 2, 3, 4, 5, 6, 7, 8]),
notBeat(X/Y, Others).


notBeat(_, []).

notBeat(X/Y, [X1/Y1 | Others]) :-
Y =\= Y1,
Y1-Y =\= X1-X,
Y1-Y =\= X-X1,
notBeat(X/Y, Others).