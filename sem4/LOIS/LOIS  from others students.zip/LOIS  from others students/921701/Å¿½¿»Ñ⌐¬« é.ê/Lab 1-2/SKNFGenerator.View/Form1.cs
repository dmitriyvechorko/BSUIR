﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SKNF_Checker;

namespace SKNFGenerator.View
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1_TextChanged(textBox1,null);
            textBox3_TextChanged(textBox3, null);
            textBox5_TextChanged(textBox5, null);
            textBox7_TextChanged(textBox7, null);
            textBox9_TextChanged(textBox9, null);

            textBox12_TextChanged(textBox12, null);
            textBox14_TextChanged(textBox14, null);
            textBox16_TextChanged(textBox16, null);
            textBox18_TextChanged(textBox18, null);
            textBox20_TextChanged(textBox20, null);
        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox) sender;

            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox2.Text = result;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;


            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox4.Text = result;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;


            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox6.Text = result;
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;


            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox8.Text = result;
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;


            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox10.Text = result;
        }

        private void textBox20_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;


            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox19.Text = result;
        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;


            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox17.Text = result;
        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;


            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox15.Text = result;
        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;


            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox13.Text = result;
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;


            var result = SknfGenerator.GeneratePcnf(textBox.Text);

            textBox11.Text = result;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}