﻿% Лабораторная работа №3 по дисциплине ЛОИС
% Выполнена студенткой гр. 921701 БГУИР Минеевым Владиславом Александровичем
% 11.05.2021
% Файл с точкой входа и реализацей решения задачи.
% Вариант 11: Задача - игра в пятнашки.
% Литература - Братко И. "Алгоритмы искусственного интеллекта на языке Prolog"

%d(Node,SonNode,Cost) определяет узел, его преемника и стоимость дуги между ними
d([Free|Counters],[ Counter|Countersl],1):- %Вседугистоят 1
	exchange(Free, Counter, Counters, Countersl). %Передвинуть фишку Counter на пустое место Freeв вписке Counters

exchange(Free, Counter,[ Counter| Subtrees],[ Free | Subtrees]):- manhattandist(Free, Counter,1).
%Если они рядом(манхэттенскоерасстояние = 1)

exchange(Free, Counter,[ Cn | Subtrees],[ Cn | Subtreesl]):-
	exchange(Free, Counter, Subtrees, Subtreesl).

manhattandist(X/Y,Xl/Yl,Md):-
	dif(X,Xl, Mdx),
	dif(Y,Yl, Mdy),
	Md is Mdx + Mdy.

dif(A,B, Md):- % Mdравно |A-B|
	Md is A-B, Md>=0,!
	;
	Md is B-A.

%подсчет эвр.
heuristic([_|Counters],H):-
	aim([_|GoalCells]),
	sumdist(Counters,GoalCells, Md), %Md- сумма расстояний от каждой фишки до ее "конечной" клетки
	orderliness(Counters,S), % оценкаупорядоченности
	H is Md + 4*S.
sumdist([],[],0).
sumdist([Counter|Counters],[Cell| Cells], Md):-
	manhattandist(Counter, Cell, Md1),
	sumdist(Counters, Cells, Md2),
	Md is Md1 + Md2.
	
%orderliness(CounterPositions, Mark)
orderliness([First|OtherCounters],S):-
	orderliness([First|OtherCounters],First,S).
orderliness([Counter1, Counter2|Counters],First,S):-
	mark(Counter1, Counter2,S1),
	orderliness([Counter2|Counters],First,S2),
	S is S1 + S2.
orderliness([Last],First,S):-
	mark(Last,First,S).
	
mark(4/1,_,1):-!. %Оценка пустой фишки равна 1
mark(1/4,2/4,0):-!. %Описание оценок фишек с допустимыми преемниками
mark(2/4,3/4,0):-!.
mark(3/4,4/4,0):-!.
mark(4/4,1/3,0):-!.
mark(1/3,2/3,0):-!.
mark(2/3,3/3,0):-!.
mark(3/3,4/3,0):-!.
mark(4/3,1/2,0):-!.
mark(1/2,2/2,0):-!.
mark(2/2,3/2,0):-!.
mark(3/2,4/2,0):-!.
mark(4/2,1/1,0):-!.
mark(1/1,2/1,0):-!.
mark(2/1,3/1,0):-!.
mark(_,_,2). %Если преемник недопустим

aim([4/1,1/4,2/4,3/4,4/4,1/3,2/3,3/3,4/3,1/2,2/2,3/2,4/2,1/1,2/1,3/1]).

%Показать список позиций на доске, которые встречались на пути к цели
seedecision([]).
seedecision([W |L]):-
	seedecision(L),
	nl,nl, write('------'),
	nl,
	seepos(W).%Показатьпозициюнадоске
seepos([S0,S1,S2,S3,S4,S5,S6,S7,S8,S9,S10,S11,S12,S13,S14,S15]):-
	member(Y,[4,3,2,1]), %Последовательностькоординат Y
	nl, member(X,[1,2,3,4]) , %Последовательность координат X
	member(Counter-X/Y, %Фишкавклетке X/Y
	[' '-S0,1-S1,2-S2,3-S3,4-S4,5-S5,6-S6,7-S7,8-S8,9-S9,10-S10,11-S11,12-S12,13-S13,14-S14,15-S15]),
	write(Counter),
	fail %Выполнить перебор с возвратом к следующей клетке
	;
	true. %Все клетки выведены
solve(Start, Decision):-
	expo([],l(Start,0/0),15000,_,yes, Decision).
% 15000 – ограничение для f-значений
%expo(Way,Tree, Tie,Tree1, Decided, Decision):
% Way -путь от начального узла поиска до поддерева
%Three 1 - дерево Three, развернутое в пределах ограничения;
%если цель найдена, то Decision - путь решения и Decided = yes
%1 Лист-узел и есть цель

expo(W,l(N,_),_,_,yes,[N| W]):-
	aim(N).
%2. Лист-узел не цель, но f-значение меньше чем ограничение
%Сформулировать узлы-преемники и развернуть их
%впределах Tie
expo(W,l(N,F/G), Tie,Treel, Decided,Dec) :-
	F=< Tie,
	(bagof(M/C,( d(N,M,C),not(member(M, W))), Sons),
	!, %Sons – узлы преемникиС
	orderlist(G,Sons,Subtrees), %упорядочитьподдеревья Subtrees
	thebestf(Subtrees,Fl), %найти лучшее f-значение, выбрать преемника
	expo(W,t(N,Fl/G, Subtrees), Tie,Treel, Decided, Dec)
	;
	Decided=never). %Узел N не имеет преемников
%3. Рассматриваемый узел Nне имеет преемников, f-значение меньше чем Tie.
% Развернуть наиболее перспективное дерево.
% Процедура follow примет решение,как дальше действовать
expo(W,t(N,F/G,[T| Subtrees]), Tie,Treel, Decided, Dec):-
	F=< Tie,
	thebestf(Subtrees,BF),
	min(Tie,BF, Tiel),
	expo([N| W],T, Tiel,Cn, Decidedl, Dec),
	follow(W,t(N,F/G,[Cn| Subtrees]),
	Tie,Treel, Decidedl, Decided, Dec).
% 4. Не лист-узел с пустыми поддеревьями. Решение не может быть найдено
expo(_,t(_,_,[]),_,_,never,_):-!.
%5. Получено f-значение больше, чем Tie. Дерево больше не может расти
expo(_,Tree, Tie,Tree,no,_):-
	f(Tree,F),F> Tie.
% follow (Way, Tree, Tie, NewTree,SubtreeDecided,TreeDecided,Decision)
follow(_,_,_,_,yes,yes,_).
follow(W,t(N,_/G,[ Cn | Subtrees]), Tie, Treel,no, Decided, Dec):-
	insert(Cn, Subtrees,NSubtrees),
	thebestf(NSubtrees,Fl),
	expo(W,t(N,Fl/G,NSubtrees),Tie,Treel, Decided, Dec).
follow(W,t(N,_/G,[_| Subtrees]), Tie,Treel,never, Decided, Dec):-
	thebestf(Subtrees,Fl),
	expo(W,t(N,Fl/G, Subtrees), Tie,Treel, Decided, Dec).
%упорядочить список листьев по F-значениям
orderlist(_,[],[]).
orderlist(Do,[N/C|NCs], Subtrees):-
	G is Do + C,
	heuristic(N,H),
	F is G+H,
	orderlist(Do,NCs, Subtreesl),
	insert(l(N,F/G), Subtreesl, Subtrees).
%Вставить дерево в список деревьев Subtreesупорядоченно по f-значениям.
insert(T, Subtrees,[T| Subtrees]):-
	f(T,F), thebestf(Subtrees,Fl),
	F=<Fl,!.
insert(T,[ Cn | Subtrees],[ Cn | Subtreesl]):-
	insert(T, Subtrees, Subtreesl).
%Получить f-значение
f(l(_,F/_),F).
f(t(_,F/_,_),F).
thebestf([T|_],F):- %Лучшее f-значение в списке деревьев
f(T,F).
thebestf([],15000). %Деревья отсутствуют. Неприемлемое f-значение
min(X,Y,X) :- X=<Y,!.
min(_,Y,Y).

%Начальная позиция
start1([1/4,1/1,2/4,3/4,4/4,1/3,2/3,3/3,4/3,1/2,2/2,3/2,4/2,4/1,2/1,3/1]).
start2([3/1,1/4,2/4,3/4,4/4,1/3,2/3,3/3,4/3,1/2,2/2,3/2,4/2,1/1,2/1,4/1]).
start3([4/3,1/4,2/4,3/4,4/4,1/3,2/3,3/3,1/2,2/2,3/2,4/2,1/1,2/1,3/1,4/1]).
start4([1/1,1/4]).
% запуск  start2(Pos), solve(Pos, Des), seedecision(Des).